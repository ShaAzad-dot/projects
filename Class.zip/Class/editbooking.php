<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'class');
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Fetch booking data
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM student_classes WHERE id=$id");
$booking = $result->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_name = $_POST['student_name'];
    $course_name = $_POST['course_name'];
    $class_type = $_POST['class_type'];
    $class_method = $_POST['class_method'];
    $class_time = $_POST['class_time'];
    $duration_minutes = $_POST['duration_minutes'];
    
    // Check time conflicts (excluding current booking)
    $end_time = date('H:i:s', strtotime("+$duration_minutes minutes", strtotime($class_time)));
    $buffer_time = date('H:i:s', strtotime("+20 minutes", strtotime($end_time)));
    
    $sql = "SELECT id, student_name, class_time, 
            ADDTIME(class_time, SEC_TO_TIME(duration_minutes * 60)) as end_time 
            FROM student_classes 
            WHERE class_type = '$class_type' 
            AND id != $id
            AND (
                (class_time BETWEEN '$class_time' AND '$buffer_time') 
                OR 
                (ADDTIME(class_time, SEC_TO_TIME(duration_minutes * 60)) BETWEEN '$class_time' AND '$buffer_time')
            )";
    
    $conflicts = $conn->query($sql);
    
    if ($conflicts->num_rows > 0) {
        $error_message = "Time conflict detected for $class_type classes!<br>";
        while($row = $conflicts->fetch_assoc()) {
            $error_message .= "⏰ {$row['student_name']} has class from {$row['class_time']} to {$row['end_time']}<br>";
        }
    } else {
        $update_sql = "UPDATE student_classes SET 
                      student_name=?, course_name=?, class_type=?, 
                      class_method=?, class_time=?, duration_minutes=?
                      WHERE id=?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("sssssii", $student_name, $course_name, $class_type, 
                         $class_method, $class_time, $duration_minutes, $id);
        
        if ($stmt->execute()) {
            $success_message = "🎉 Booking updated successfully!";
            // Refresh data
            $result = $conn->query("SELECT * FROM student_classes WHERE id=$id");
            $booking = $result->fetch_assoc();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Booking</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fa; margin: 0; padding: 20px; }
        .container { max-width: 600px; margin: 30px auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        h1 { color: #4a6baf; text-align: center; margin-bottom: 30px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: 600; color: #555; }
        input, select { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px; }
        button { background: #4a6baf; color: white; border: none; padding: 12px 20px; border-radius: 5px; cursor: pointer; font-size: 16px; width: 100%; }
        button:hover { background: #3a5a9f; }
        .alert { padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .alert-danger { background: #ffebee; color: #c62828; border-left: 4px solid #c62828; }
        .alert-success { background: #e8f5e9; color: #2e7d32; border-left: 4px solid #2e7d32; }
        .back-btn { display: inline-block; margin-top: 20px; text-decoration: none; color: #4a6baf; font-weight: 600; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Booking</h1>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="student_name">Student Name</label>
                <input type="text" id="student_name" name="student_name" value="<?php echo htmlspecialchars($booking['student_name']); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="course_name">Course Name</label>
                <input type="text" id="course_name" name="course_name" value="<?php echo htmlspecialchars($booking['course_name']); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="class_type">Class Type</label>
                <select id="class_type" name="class_type" required>
                    <option value="Regular" <?php echo ($booking['class_type'] == 'Regular') ? 'selected' : ''; ?>>Regular (Mon-Fri)</option>
                    <option value="Weekend" <?php echo ($booking['class_type'] == 'Weekend') ? 'selected' : ''; ?>>Weekend (Sat-Sun)</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="class_method">Class Method</label>
                <select id="class_method" name="class_method" required>
                    <option value="1:1" <?php echo ($booking['class_method'] == '1:1') ? 'selected' : ''; ?>>1:1</option>
                    <option value="Group" <?php echo ($booking['class_method'] == 'Group') ? 'selected' : ''; ?>>Group</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="class_time">Class Time</label>
                <input type="time" id="class_time" name="class_time" value="<?php echo date('H:i', strtotime($booking['class_time'])); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="duration_minutes">Duration (minutes)</label>
                <input type="number" id="duration_minutes" name="duration_minutes" min="1" value="<?php echo $booking['duration_minutes']; ?>" required>
            </div>
            
            <button type="submit">Update Booking</button>
        </form>
        
        <a href="managebooking.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Manage Bookings</a>
    </div>
</body>
</html>