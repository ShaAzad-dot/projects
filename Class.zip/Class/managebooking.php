<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'class');
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Handle delete action
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM student_classes WHERE id=$id");
    header("Location: managebooking.php");
    exit();
}

// Search and sort logic
$search = isset($_GET['search']) ? $_GET['search'] : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'class_time';
$order = isset($_GET['order']) ? $_GET['order'] : 'ASC';

$sql = "SELECT * FROM student_classes 
        WHERE student_name LIKE '%$search%' OR course_name LIKE '%$search%'
        ORDER BY $sort $order";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bookings</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        h1 {
            color: #4a6baf;
            text-align: center;
            margin-bottom: 30px;
        }
        .search-sort {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }
        .search-box {
            flex: 1;
            min-width: 300px;
            position: relative;
        }
        .search-box input {
            width: 100%;
            padding: 10px 15px 10px 40px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        .search-box i {
            position: absolute;
            left: 15px;
            top: 12px;
            color: #777;
        }
        .sort-options select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #4a6baf;
            color: white;
            cursor: pointer;
            position: relative;
        }
        th:hover {
            background-color: #3a5a9f;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        .edit-btn, .delete-btn {
            padding: 5px 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            color: white;
            font-size: 14px;
        }
        .edit-btn {
            background-color: #4CAF50;
        }
        .edit-btn:hover {
            background-color: #45a049;
        }
        .delete-btn {
            background-color: #f44336;
        }
        .delete-btn:hover {
            background-color: #d32f2f;
        }
        .sort-icon {
            margin-left: 5px;
        }
        .no-records {
            text-align: center;
            padding: 20px;
            color: #777;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Manage Bookings</h1>
        
        <div class="search-sort">
            <div class="search-box">
                <i class="fas fa-search"></i>
                <input type="text" id="search" name="search" placeholder="Search by student or course..." 
                       value="<?php echo htmlspecialchars($search); ?>" onkeyup="if(event.keyCode==13) searchTable()">
            </div>
            <div class="sort-options">
                <select onchange="sortTable()" id="sort-select">
                    <option value="class_time" <?php echo ($sort == 'class_time') ? 'selected' : ''; ?>>Sort by Time</option>
                    <option value="student_name" <?php echo ($sort == 'student_name') ? 'selected' : ''; ?>>Sort by Student</option>
                    <option value="course_name" <?php echo ($sort == 'course_name') ? 'selected' : ''; ?>>Sort by Course</option>
                </select>
                <select onchange="sortTable()" id="order-select">
                    <option value="ASC" <?php echo ($order == 'ASC') ? 'selected' : ''; ?>>Ascending</option>
                    <option value="DESC" <?php echo ($order == 'DESC') ? 'selected' : ''; ?>>Descending</option>
                </select>
            </div>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th onclick="sortColumn('student_name')">Student Name 
                        <i class="fas fa-sort<?php echo ($sort == 'student_name') ? '-' . strtolower($order) : ''; ?> sort-icon"></i></th>
                    <th onclick="sortColumn('course_name')">Course Name 
                        <i class="fas fa-sort<?php echo ($sort == 'course_name') ? '-' . strtolower($order) : ''; ?> sort-icon"></i></th>
                    <th onclick="sortColumn('class_type')">Class Type 
                        <i class="fas fa-sort<?php echo ($sort == 'class_type') ? '-' . strtolower($order) : ''; ?> sort-icon"></i></th>
                    <th onclick="sortColumn('class_method')">Method 
                        <i class="fas fa-sort<?php echo ($sort == 'class_method') ? '-' . strtolower($order) : ''; ?> sort-icon"></i></th>
                    <th onclick="sortColumn('class_time')">Time 
                        <i class="fas fa-sort<?php echo ($sort == 'class_time') ? '-' . strtolower($order) : ''; ?> sort-icon"></i></th>
                    <th onclick="sortColumn('duration_minutes')">Duration 
                        <i class="fas fa-sort<?php echo ($sort == 'duration_minutes') ? '-' . strtolower($order) : ''; ?> sort-icon"></i></th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['course_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['class_type']); ?></td>
                            <td><?php echo htmlspecialchars($row['class_method']); ?></td>
                            <td><?php echo date('h:i A', strtotime($row['class_time'])); ?></td>
                            <td><?php echo $row['duration_minutes']; ?> mins</td>
                            <td class="action-buttons">
                                <a href="editbooking.php?id=<?php echo $row['id']; ?>" class="edit-btn">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <a href="managebooking.php?delete=<?php echo $row['id']; ?>" class="delete-btn" 
                                   onclick="return confirm('Are you sure you want to delete this booking?')">
                                    <i class="fas fa-trash-alt"></i> Delete
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="no-records">No bookings found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <script>
        function searchTable() {
            const search = document.getElementById('search').value;
            window.location.href = `managebooking.php?search=${encodeURIComponent(search)}&sort=<?php echo $sort; ?>&order=<?php echo $order; ?>`;
        }
        
        function sortTable() {
            const sort = document.getElementById('sort-select').value;
            const order = document.getElementById('order-select').value;
            const search = '<?php echo $search; ?>';
            window.location.href = `managebooking.php?search=${encodeURIComponent(search)}&sort=${sort}&order=${order}`;
        }
        
        function sortColumn(column) {
            const search = '<?php echo $search; ?>';
            let order = '<?php echo $order; ?>';
            let currentSort = '<?php echo $sort; ?>';
            
            if (column === currentSort) {
                order = (order === 'ASC') ? 'DESC' : 'ASC';
            } else {
                order = 'ASC';
            }
            
            window.location.href = `managebooking.php?search=${encodeURIComponent(search)}&sort=${column}&order=${order}`;
        }
    </script>
</body>
</html>