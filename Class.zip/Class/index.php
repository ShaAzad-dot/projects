<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'class');
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Get stats for dashboard
$total_bookings = $conn->query("SELECT COUNT(*) as total FROM student_classes")->fetch_assoc()['total'];
$regular_classes = $conn->query("SELECT COUNT(*) as total FROM student_classes WHERE class_type='Regular'")->fetch_assoc()['total'];
$weekend_classes = $conn->query("SELECT COUNT(*) as total FROM student_classes WHERE class_type='Weekend'")->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #4a6baf;
            --secondary: #6c757d;
            --success: #28a745;
            --danger: #dc3545;
            --light: #f8f9fa;
            --dark: #343a40;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8f0 100%);
            margin: 0;
            padding: 0;
            min-height: 100vh;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        h1 {
            color: var(--primary);
            margin: 0;
            font-size: 2.2rem;
        }
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            border-left: 5px solid var(--primary);
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        .stat-card h3 {
            color: var(--secondary);
            margin-top: 0;
            font-size: 1.1rem;
        }
        .stat-card .value {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary);
            margin: 10px 0;
        }
        .stat-card .icon {
            font-size: 2.5rem;
            color: var(--primary);
            opacity: 0.2;
            position: absolute;
            right: 20px;
            top: 20px;
        }
        .action-section {
            text-align: center;
            margin: 50px 0;
        }
        .action-title {
            color: var(--secondary);
            margin-bottom: 30px;
            font-size: 1.5rem;
        }
        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
        }
        .action-btn {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            width: 200px;
            height: 200px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            text-decoration: none;
            color: var(--dark);
            position: relative;
            overflow: hidden;
        }
        .action-btn:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
            color: var(--primary);
        }
        .action-btn i {
            font-size: 4rem;
            margin-bottom: 15px;
            color: var(--primary);
            transition: all 0.3s ease;
        }
        .action-btn:hover i {
            transform: scale(1.1);
        }
        .action-btn .btn-text {
            font-size: 1.2rem;
            font-weight: 600;
        }
        .illustration {
            max-width: 400px;
            margin: 0 auto;
            opacity: 0.9;
        }
        .recent-bookings {
            background: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            margin-top: 40px;
        }
        .recent-bookings h2 {
            color: var(--primary);
            margin-top: 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        th {
            background-color: var(--primary);
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .pulse {
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
    </style>
</head>
<body>
    <div class="container">
        <header class="animate__animated animate__fadeInDown">
            <h1>Booking Dashboard</h1>
            <div class="date"><?php echo date('l, F j, Y'); ?></div>
        </header>

        <div class="dashboard-grid">
            <div class="stat-card animate__animated animate__fadeInLeft">
                <div class="icon"><i class="fas fa-calendar-alt"></i></div>
                <h3>Total Bookings</h3>
                <div class="value"><?php echo $total_bookings; ?></div>
                <p>All time scheduled classes</p>
            </div>
            
            <div class="stat-card animate__animated animate__fadeInUp">
                <div class="icon"><i class="fas fa-calendar-day"></i></div>
                <h3>Regular Classes</h3>
                <div class="value"><?php echo $regular_classes; ?></div>
                <p>Mon-Fri scheduled classes</p>
            </div>
            
            <div class="stat-card animate__animated animate__fadeInRight">
                <div class="icon"><i class="fas fa-calendar-week"></i></div>
                <h3>Weekend Classes</h3>
                <div class="value"><?php echo $weekend_classes; ?></div>
                <p>Sat-Sun scheduled classes</p>
            </div>
        </div>

        <div class="action-section animate__animated animate__fadeIn">
            <h2 class="action-title">Quick Actions</h2>
            <div class="action-buttons">
                <a href="addbooking.php" class="action-btn pulse animate__animated animate__pulse animate__infinite">
                    <i class="fas fa-plus-circle"></i>
                    <span class="btn-text">Add Booking</span>
                </a>
                <a href="managebooking.php" class="action-btn">
                    <i class="fas fa-tasks"></i>
                    <span class="btn-text">Manage Bookings</span>
                </a>
            </div>
        </div>

        <div class="illustration animate__animated animate__zoomIn">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 300">
                <style>
                    .cls-1{fill:#e6e6e6;}.cls-2{fill:#f2f2f2;}.cls-3{fill:#fff;}.cls-4{fill:#4a6baf;}.cls-5{fill:#6c757d;}.cls-6{fill:#28a745;}.cls-7{fill:#dc3545;}
                </style>
                <rect class="cls-1" x="50" y="50" width="400" height="200" rx="10"/>
                <rect class="cls-2" x="70" y="70" width="360" height="160" rx="5"/>
                <rect class="cls-3" x="90" y="90" width="320" height="120" rx="3"/>
                <circle class="cls-4" cx="120" cy="120" r="15"/>
                <circle class="cls-5" cx="120" cy="160" r="15"/>
                <circle class="cls-6" cx="120" cy="200" r="15"/>
                <rect class="cls-4" x="160" y="110" width="150" height="20" rx="3"/>
                <rect class="cls-5" x="160" y="150" width="200" height="20" rx="3"/>
                <rect class="cls-6" x="160" y="190" width="100" height="20" rx="3"/>
                <circle class="cls-7" cx="400" cy="150" r="25"/>
                <path class="cls-3" d="M390,140l20,20-20,20" stroke-width="5" stroke="#fff"/>
            </svg>
        </div>

        <div class="recent-bookings animate__animated animate__fadeInUp">
            <h2>Recent Bookings</h2>
            <table>
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Course</th>
                        <th>Type</th>
                        <th>Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $recent = $conn->query("SELECT * FROM student_classes ORDER BY created_at DESC LIMIT 5");
                    while($row = $recent->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['course_name']); ?></td>
                            <td><?php echo $row['class_type']; ?></td>
                            <td><?php echo date('h:i A', strtotime($row['class_time'])); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Add animation to action buttons on hover
        document.querySelectorAll('.action-btn').forEach(btn => {
            btn.addEventListener('mouseenter', () => {
                btn.classList.add('animate__animated', 'animate__pulse');
            });
            btn.addEventListener('mouseleave', () => {
                btn.classList.remove('animate__animated', 'animate__pulse');
            });
        });
    </script>
</body>
</html>