<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'class');
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Check for exact time conflicts (same class type and exact time)
function getTimeConflicts($conn, $class_time, $class_type) {
    $sql = "SELECT student_name, class_time 
            FROM student_classes 
            WHERE class_type = '$class_type' 
            AND class_time = '$class_time'";
    return $conn->query($sql);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_name = $_POST['student_name'];
    $course_name = $_POST['course_name'];
    $class_type = $_POST['class_type'];
    $class_method = $_POST['class_method'];
    $class_time = $_POST['class_time'];
    $duration_minutes = $_POST['duration_minutes'];
    
    $conflicts = getTimeConflicts($conn, $class_time, $class_type);
    if ($conflicts->num_rows > 0) {
        $error_message = "Time slot already booked for $class_type classes!<br>";
        while($row = $conflicts->fetch_assoc()) {
            $error_message .= "⏰ {$row['student_name']} has class at {$row['class_time']}<br>";
        }
    } else {
        $sql = "INSERT INTO student_classes (student_name, course_name, class_type, class_method, class_time, duration_minutes) 
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssi", $student_name, $course_name, $class_type, $class_method, $class_time, $duration_minutes);
        if ($stmt->execute()) {
            $success_message = "🎉 Booking added successfully!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Booking</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            height: 100vh;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            animation: fadeInUp 0.5s;
        }
        h1 {
            color: #4a6baf;
            text-align: center;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #555;
        }
        input, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            background: #4a6baf;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            transition: all 0.3s;
        }
        button:hover {
            background: #3a5a9f;
            transform: translateY(-2px);
        }
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            animation: fadeIn 0.5s;
        }
        .alert-danger {
            background: #ffebee;
            color: #c62828;
            border-left: 4px solid #c62828;
        }
        .alert-success {
            background: #e8f5e9;
            color: #2e7d32;
            border-left: 4px solid #2e7d32;
        }
    </style>
</head>
<body>
    <div class="container animate__animated animate__fadeInUp">
        <h1>Add New Booking</h1>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger animate__animated animate__shakeX">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success animate__animated animate__bounceIn">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="student_name">Student Name</label>
                <input type="text" id="student_name" name="student_name" required>
            </div>
            
            <div class="form-group">
                <label for="course_name">Course Name</label>
                <input type="text" id="course_name" name="course_name" required>
            </div>
            
            <div class="form-group">
                <label for="class_type">Class Type</label>
                <select id="class_type" name="class_type" required>
                    <option value="Regular">Regular (Mon-Fri)</option>
                    <option value="Weekend">Weekend (Sat-Sun)</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="class_method">Class Method</label>
                <select id="class_method" name="class_method" required>
                    <option value="1:1">1:1</option>
                    <option value="Group">Group</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="class_time">Class Time</label>
                <input type="time" id="class_time" name="class_time" required>
            </div>
            
            <div class="form-group">
                <label for="duration_minutes">Duration (minutes)</label>
                <input type="number" id="duration_minutes" name="duration_minutes" min="1" required>
            </div>
            
            <button type="submit" class="animate__animated animate__pulse animate__infinite">Add Booking</button>
        </form>
    </div>
</body>
</html>