-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 06, 2025 at 01:22 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `class`
--

-- --------------------------------------------------------

--
-- Table structure for table `student_classes`
--

CREATE TABLE `student_classes` (
  `id` int(11) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `class_type` enum('Regular','Weekend') NOT NULL,
  `class_method` enum('1:1','Group') NOT NULL,
  `class_time` time NOT NULL,
  `duration_minutes` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_classes`
--

INSERT INTO `student_classes` (`id`, `student_name`, `course_name`, `class_type`, `class_method`, `class_time`, `duration_minutes`, `created_at`) VALUES
(20, 'Dr Nouman', 'Alim Course ', 'Regular', '1:1', '07:00:00', 30, '2025-04-05 23:03:53'),
(21, 'Mohammad Akhlaque', 'Alim Course', 'Regular', '1:1', '07:30:00', 30, '2025-04-05 23:04:20'),
(22, 'Sajid', 'Alim Course', 'Regular', '1:1', '09:00:00', 30, '2025-04-05 23:04:42'),
(23, 'Zainab Ansari', 'Alim Course ', 'Regular', '1:1', '10:00:00', 30, '2025-04-05 23:05:00'),
(24, 'Ahmed', 'Alim Course', 'Regular', '1:1', '15:00:00', 30, '2025-04-05 23:05:25'),
(25, 'Hafas Khalid', 'Hifz Course', 'Regular', 'Group', '15:30:00', 30, '2025-04-05 23:05:50'),
(26, 'Shahnaz Saima', 'Alim Course', 'Regular', 'Group', '16:00:00', 30, '2025-04-05 23:06:20'),
(27, 'Ayesha Hiba', 'Alim Course', 'Regular', '1:1', '16:30:00', 30, '2025-04-05 23:06:48'),
(28, 'Altaf', 'Alim Course', 'Regular', '1:1', '17:00:00', 30, '2025-04-05 23:07:16'),
(29, 'Zaina', 'Alim Course', 'Regular', '1:1', '17:30:00', 30, '2025-04-05 23:07:34'),
(30, 'Yasmeen', 'Alim Course', 'Regular', '1:1', '20:00:00', 30, '2025-04-05 23:08:02'),
(31, 'Soha Sheza Saif', 'Deeniyat', 'Regular', '1:1', '20:30:00', 30, '2025-04-05 23:08:30'),
(32, 'Abdullah ', 'Alim Course', 'Regular', '1:1', '23:00:00', 30, '2025-04-05 23:10:05'),
(33, 'Ayesha ', 'Alim Course', 'Regular', '1:1', '22:00:00', 30, '2025-04-05 23:10:28'),
(34, 'Kashifa', 'Alim Course ', 'Regular', '1:1', '21:00:00', 30, '2025-04-05 23:11:07'),
(35, 'Group', 'Alim Course', 'Regular', '1:1', '21:30:00', 30, '2025-04-05 23:11:35'),
(36, 'Ayaz', 'Alim Course', 'Regular', '1:1', '22:30:00', 30, '2025-04-05 23:12:36'),
(37, 'Nouman', 'Deeniyat', 'Regular', '1:1', '19:00:00', 30, '2025-04-05 23:14:54'),
(38, 'Faman', 'Alim Course', 'Regular', '1:1', '23:30:00', 30, '2025-04-05 23:15:57'),
(39, 'Iliyas', 'Alim Course', 'Regular', '1:1', '00:30:00', 30, '2025-04-05 23:16:51'),
(41, 'Max', 'Alim', 'Weekend', '1:1', '19:00:00', 120, '2025-04-05 23:18:24'),
(42, 'Junaid', 'Alim Course', 'Weekend', '1:1', '09:30:00', 180, '2025-04-05 23:19:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student_classes`
--
ALTER TABLE `student_classes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student_classes`
--
ALTER TABLE `student_classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
