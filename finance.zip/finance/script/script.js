document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("login-link").addEventListener("click", function(event) {
        event.preventDefault();
        var loginForm = document.getElementById("login-form");
        if (loginForm.style.display === "none") {
            loginForm.style.display = "block";
        } else {
            loginForm.style.display = "none";
        }
    });
});
