<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "finance";

$connection = mysqli_connect($host, $user, $password, $database);

// Check connection
if (mysqli_connect_errno()) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
