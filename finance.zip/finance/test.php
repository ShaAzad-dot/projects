To generate a repayment schedule for a loan on a monthly basis, we need to calculate the monthly interest, monthly principal, and remaining balance for each month of the loan tenure. Here's how you can do it in PHP:

```php
<?php
// Given loan details
$principleAmount = 815000;
$emiTenure = 84;
$monthlyEMI = 14700;
$interestRatePerAnnum = 8.5 / 100; // Assuming annual interest rate is 8.5%

// Initialize repayment schedule array
$repaymentSchedule = array();

// Calculate monthly interest rate
$monthlyInterestRate = $interestRatePerAnnum / 12;

// Remaining balance
$remainingBalance = $principleAmount;

// Calculate repayment schedule for each month
for ($month = 1; $month <= $emiTenure; $month++) {
    // Calculate monthly interest
    $monthlyInterest = $remainingBalance * $monthlyInterestRate;

    // Calculate monthly principal
    $monthlyPrincipal = $monthlyEMI - $monthlyInterest;

    // Update remaining balance
    $remainingBalance -= $monthlyPrincipal;

    // Add entry to repayment schedule
    $repaymentSchedule[] = array(
        'month' => $month,
        'emi_amount' => $monthlyEMI,
        'monthly_principle' => $monthlyPrincipal,
        'monthly_interest' => $monthlyInterest,
        'remaining_balance' => $remainingBalance
    );
}

// Display repayment schedule
echo "<table border='1'>";
echo "<tr><th>Month</th><th>EMI Amount</th><th>Monthly Principal</th><th>Monthly Interest</th><th>Remaining Balance</th></tr>";
foreach ($repaymentSchedule as $schedule) {
    echo "<tr>";
    echo "<td>{$schedule['month']}</td>";
    echo "<td>{$schedule['emi_amount']}</td>";
    echo "<td>{$schedule['monthly_principle']}</td>";
    echo "<td>{$schedule['monthly_interest']}</td>";
    echo "<td>{$schedule['remaining_balance']}</td>";
    echo "</tr>";
}
echo "</table>";
?>
```

This code will calculate and display the repayment schedule for each month of the loan tenure, including the EMI amount, monthly principal, monthly interest, and remaining balance. Adjust the given loan details and interest rate as per your requirement.