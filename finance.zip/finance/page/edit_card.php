
<?php
 require_once 'includes/header.php'; 
// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    echo "Error: No card ID provided.";
    exit();
}

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch card details based on ID
$id = $_GET['id'];
$sql = "SELECT * FROM credit_cards WHERE card_id = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Error: Card not found.";
    exit();
}

// Initialize variables with current data
$cardName = $row['card_name'];
$totalLimit = $row['total_limit'];
$availableLimit = $row['available_limit'];
$cardOwner = $row['card_owner'];

// Update card details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cardName = $_POST["card_name"];
    $totalLimit = $_POST["total_limit"];
    $availableLimit = $_POST["available_limit"];
    $cardOwner = $_POST["card_owner"];

    $updateSql = "UPDATE credit_cards SET card_name='$cardName', total_limit='$totalLimit', available_limit='$availableLimit', card_owner='$cardOwner' WHERE card_id=$id";

    if ($conn->query($updateSql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>Record updated successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error updating record: " . $conn->error . "</div></div>";
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Credit Card Details</title>
    <!-- Bootstrap CSS -->
 
<body>
    <div class="container mt-5">
        <h2>Edit Credit Card Details</h2>
        <form id="limitForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $id; ?>" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="card_name">Card Name:</label>
                <input type="text" class="form-control" id="card_name" name="card_name" value="<?php echo $cardName; ?>" required>
                <div class="invalid-feedback">Please enter the card name.</div>
            </div>
            <div class="form-group">
                <label for="total_limit">Total Limit:</label>
                <input type="number" class="form-control" id="total_limit" name="total_limit" value="<?php echo $totalLimit; ?>" required>
                <div class="invalid-feedback">Please enter the total limit.</div>
            </div>
            <div class="form-group">
                <label for="available_limit">Available Limit:</label>
                <input type="number" class="form-control" id="available_limit" name="available_limit" value="<?php echo $availableLimit; ?>" required>
                <div class="invalid-feedback">Please enter the available limit.</div>
            </div>
            <div class="form-group">
                <label for="utilized_limit">Utilized Limit:</label>
                <input type="text" class="form-control" id="utilized_limit" name="utilized_limit" value="<?php echo ($totalLimit - $availableLimit); ?>" readonly>
            </div>
            <div class="form-group">
                <label for="card_owner">Card Owner:</label>
                <input type="text" class="form-control" id="card_owner" name="card_owner" value="<?php echo $cardOwner; ?>" required>
                <div class="invalid-feedback">Please enter the card owner.</div>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="credit_cards.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Form validation script -->
    <script>
        // JavaScript for form validation
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();

        // Function to update utilized limit in real time
        function updateUtilizedLimit() {
            var totalLimit = parseFloat(document.getElementById('total_limit').value);
            var availableLimit = parseFloat(document.getElementById('available_limit').value);
            var utilizedLimit = totalLimit - availableLimit;
            document.getElementById('utilized_limit').value = utilizedLimit.toFixed(2);
        }

        // Attach event listeners to total limit and available limit inputs
        document.getElementById('total_limit').addEventListener('input', updateUtilizedLimit);
        document.getElementById('available_limit').addEventListener('input', updateUtilizedLimit);

        // Call the function initially to populate utilized limit
        updateUtilizedLimit();
    </script>
</body>
</html>
