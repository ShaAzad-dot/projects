<?php require_once 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Credit Card Details</title>
    <!-- Bootstrap CSS -->
  
</head>
<body>
    <div class="container mt-5">
        <ol class="breadcrumb">
            <li><a href="dashboard.php">Home</a></li>
            <li class="active">Add Credit Card</li>
        </ol>
        <div class="card shadow-lg p-4">
            <h2 class="mb-4">Add Credit Card Details</h2>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="needs-validation" novalidate>
                <div class="form-group">
                    <label for="card_name">Card Name:</label>
                    <input type="text" class="form-control" id="card_name" name="card_name" required>
                    <div class="invalid-feedback">Please enter the card name.</div>
                </div>
                <div class="form-group">
                    <label for="total_limit">Total Limit:</label>
                    <input type="text" class="form-control" id="total_limit" name="total_limit" required>
                    <div class="invalid-feedback">Please enter the total limit.</div>
                </div>
                <div class="form-group">
                    <label for="available_limit">Available Limit:</label>
                    <input type="text" class="form-control" id="available_limit" name="available_limit" required>
                    <div class="invalid-feedback">Please enter the available limit.</div>
                </div>
                <div class="form-group">
                    <label for="utilized_limit">Utilized Limit:</label>
                    <input type="text" class="form-control" id="utilized_limit" name="utilized_limit" readonly>
                </div>
                <div class="form-group">
                    <label for="card_owner">Card Owner:</label>
                    <input type="text" class="form-control" id="card_owner" name="card_owner" required>
                    <div class="invalid-feedback">Please enter the card owner.</div>
                </div>
                <button type="submit" class="btn btn-primary btn-block"><i class="glyphicon glyphicon-plus-sign"></i> Submit</button>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                var forms = document.getElementsByClassName('needs-validation');
                Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();

        function calculateUtilizedLimit() {
            var totalLimit = parseFloat(document.getElementById('total_limit').value) || 0;
            var availableLimit = parseFloat(document.getElementById('available_limit').value) || 0;
            var utilizedLimit = totalLimit - availableLimit;
            document.getElementById('utilized_limit').value = utilizedLimit.toFixed(2);
        }

        document.getElementById('total_limit').addEventListener('input', calculateUtilizedLimit);
        document.getElementById('available_limit').addEventListener('input', calculateUtilizedLimit);
    </script>
</body>
</html>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "finance";
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cardName = $_POST["card_name"];
    $totalLimit = $_POST["total_limit"];
    $availableLimit = $_POST["available_limit"];
    $cardOwner = $_POST["card_owner"];
    $sql = "INSERT INTO credit_cards (card_name, total_limit, available_limit, card_owner) VALUES ('$cardName', '$totalLimit', '$availableLimit', '$cardOwner')";
    if ($conn->query($sql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>New record created successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error: " . $sql . "<br>" . $conn->error . "</div></div>";
    }
}
$conn->close();
?>