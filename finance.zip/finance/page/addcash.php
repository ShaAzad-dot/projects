
<?php require_once 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Cash Details</title>
    <!-- Bootstrap CSS -->
  
</head>
<body>
    <div class="container mt-5">
		<ol class="breadcrumb">
            <li><a href="dashboard.php">Home</a></li>		  
            <li class="active"> Add Cash</li>
        </ol>
        <h2>Add Cash Details</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="cash_from">Cash From:</label>
                <input type="text" class="form-control" id="cash_from" name="cash_from" required>
                <div class="invalid-feedback">Please enter the source of cash.</div>
            </div>
            <div class="form-group">
                <label for="cash_amount">Cash Amount:</label>
                <input type="text" class="form-control" id="cash_amount" name="cash_amount" required>
                <div class="invalid-feedback">Please enter the amount of cash.</div>
            </div>
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" class="form-control" id="date" name="date" required>
                <div class="invalid-feedback">Please select the date.</div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-plus-sign"></i> Submit</button>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Form validation script -->
    <script>
        // JavaScript for form validation
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
    </script>
</body>
</html>

<?php
// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables to store form data
$cashFrom = $cashAmount = $date = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $cashFrom = $_POST["cash_from"];
    $cashAmount = $_POST["cash_amount"];
    $date = $_POST["date"];

    // SQL to insert data into table
    $sql = "INSERT INTO cash (Cash_From, Cash_Amount, Date)
            VALUES ('$cashFrom', '$cashAmount', '$date')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>New record created successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error: " . $sql . "<br>" . $conn->error . "</div></div>";
    }
}

// Close connection
$conn->close();
?>
