Sure, here's the adapted code to edit details from the "Credit" table:

```php
<?php
require_once 'includes/header.php'; 

// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    echo "Error: No credit ID provided.";
    exit();
}

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch credit details based on ID
$id = $_GET['id'];
$sql = "SELECT * FROM Credit WHERE ID = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Error: Credit not found.";
    exit();
}

// Initialize variables with current data
$name = $row['name'];
$amount = $row['amount'];
$purpose = $row['purpose'];
$pendingAmount = $row['pending_amount'];
$paidAmount = $row['paid_amount'];
$lastUpdateDate = $row['last_update_date'];

// Update credit details if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $amount = $_POST["amount"];
    $purpose = $_POST["purpose"];
    $pendingAmount = $_POST["pending_amount"];
    $paidAmount = $_POST["paid_amount"];
    $lastUpdateDate = $_POST["last_update_date"];

    // Update SQL query
    $updateSql = "UPDATE Credit SET Name='$name', Amount='$amount', Purpose='$purpose', Pending_Amount='$pendingAmount', Paid_Amount='$paidAmount', Last_Update_Date='$lastUpdateDate' WHERE ID=$id";

    if ($conn->query($updateSql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>Record updated successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error updating record: " . $conn->error . "</div></div>";
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Credit Details</title>
    <!-- Bootstrap CSS -->
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Credit Details</h2>
        <form id="creditForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $id; ?>" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>" required>
                <div class="invalid-feedback">Please enter the name.</div>
            </div>
            <div class="form-group">
                <label for="amount">Amount:</label>
                <input type="text" class="form-control" id="amount" name="amount" value="<?php echo $amount; ?>" required>
                <div class="invalid-feedback">Please enter the amount.</div>
            </div>
            <div class="form-group">
                <label for="purpose">Purpose:</label>
                <input type="text" class="form-control" id="purpose" name="purpose" value="<?php echo $purpose; ?>" required>
                <div class="invalid-feedback">Please enter the purpose.</div>
            </div>
            <div class="form-group">
                <label for="pending_amount">Pending Amount:</label>
                <input type="text" class="form-control" id="pending_amount" name="pending_amount" value="<?php echo $pendingAmount; ?>" required>
                <div class="invalid-feedback">Please enter the pending amount.</div>
            </div>
            <div class="form-group">
                <label for="paid_amount">Paid Amount:</label>
                <input type="text" class="form-control" id="paid_amount" name="paid_amount" value="<?php echo $paidAmount; ?>" required>
                <div class="invalid-feedback">Please enter the paid amount.</div>
            </div>
            <div class="form-group">
                <label for="last_update_date">Last Update Date:</label>
                <input type="date" class="form-control" id="last_update_date" name="last_update_date" value="<?php echo $lastUpdateDate; ?>" required>
                <div class="invalid-feedback">Please enter the last update date.</div>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="debt_details.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Form validation script -->
    <script>
        // JavaScript for form validation
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
		
		// Function to calculate pending amount
		        function calculatePendingAmount() {
            var amount = parseFloat(document.getElementById('amount').value);
            var paidAmount = parseFloat(document.getElementById('paid_amount').value);
            var pendingAmount = amount - paidAmount;

            // Display the result in the pending amount input field
            document.getElementById('pending_amount').value = pendingAmount.toFixed(2);
        }

        // Event listener to trigger the calculation when paid amount input value changes
        document.getElementById('paid_amount').addEventListener('input', calculatePendingAmount);
    </script>
</body>
</html>
