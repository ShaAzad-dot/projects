<?php
require_once 'includes/header.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database connection
$conn = new mysqli("localhost", "root", "", "finance");
if ($conn->connect_error) {
    die("<div class='alert alert-danger'>Connection failed: " . $conn->connect_error . "</div>");
}

// Get logged-in user ID from session (replace with your actual session variable)
$user_id = $_SESSION['user_id'] ?? 1; // Defaulting to 1 for demo

// Fetch user details using prepared statement
$stmt = $conn->prepare("SELECT id, username, email, mobile, password_hash, created_at FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    die("<div class='alert alert-danger'>User not found</div>");
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile | Finance App</title>
    <!-- Bootstrap 5 CSS -->
  
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --light-bg: #f8f9fa;
        }
        
        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .profile-card {
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            overflow: hidden;
            margin-top: 30px;
        }
        
        .profile-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 30px 20px;
            text-align: center;
        }
        
        .profile-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            border: 3px solid white;
            object-fit: cover;
            margin-bottom: 15px;
            background-color: #fff;
        }
        
        .profile-details {
            background-color: white;
            padding: 25px;
        }
        
        .detail-item {
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        
        .detail-item:last-child {
            border-bottom: none;
        }
        
        .detail-label {
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .password-field {
            position: relative;
        }
        
        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="profile-card">
                    <div class="profile-header">
                        <img src="https://ui-avatars.com/api/?name=<?= urlencode($user['username']) ?>&background=random" 
                             class="profile-avatar" alt="User Avatar">
                        <h3><?= htmlspecialchars($user['username']) ?></h3>
                        <p class="mb-0">Member since <?= date('F Y', strtotime($user['created_at'])) ?></p>
                    </div>
                    
                    <div class="profile-details">
                        <div class="detail-item row">
                            <div class="col-md-4 detail-label">User ID</div>
                            <div class="col-md-8"><?= htmlspecialchars($user['id']) ?></div>
                        </div>
                        
                        <div class="detail-item row">
                            <div class="col-md-4 detail-label">Username</div>
                            <div class="col-md-8"><?= htmlspecialchars($user['username']) ?></div>
                        </div>
                        
                        <div class="detail-item row">
                            <div class="col-md-4 detail-label">Email Address</div>
                            <div class="col-md-8">
                                <?= htmlspecialchars($user['email']) ?>
                                <span class="badge bg-<?= filter_var($user['email'], FILTER_VALIDATE_EMAIL) ? 'success' : 'warning' ?> ms-2">
                                    <?= filter_var($user['email'], FILTER_VALIDATE_EMAIL) ? 'Valid' : 'Invalid' ?>
                                </span>
                            </div>
                        </div>
                        
                        <div class="detail-item row">
                            <div class="col-md-4 detail-label">Mobile Number</div>
                            <div class="col-md-8">
                                <?= $user['mobile'] ? htmlspecialchars($user['mobile']) : '<span class="text-muted">Not provided</span>' ?>
                            </div>
                        </div>
                        
                        <div class="detail-item row password-field">
                            <div class="col-md-4 detail-label">Password</div>
                            <div class="col-md-8">
                                <input type="password" value="<?= htmlspecialchars($user['password_hash']) ?>" 
                                       class="form-control-plaintext" id="passwordField" readonly>
                                <i class="fas fa-eye password-toggle" id="togglePassword"></i>
                            </div>
                        </div>
                        
                        <div class="detail-item row">
                            <div class="col-md-4 detail-label">Account Created</div>
                            <div class="col-md-8">
                                <?= date('F j, Y \a\t g:i A', strtotime($user['created_at'])) ?>
                            </div>
                        </div>
                        
                        <div class="detail-item row mt-4">
                            <div class="col-12 d-flex justify-content-between">
                                <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editProfileModal">
                                    <i class="fas fa-edit me-2"></i>Edit Profile
                                </button>
                                <button class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#changePasswordModal">
                                    <i class="fas fa-key me-2"></i>Change Password
                                </button>
                                <a href="logout.php" class="btn btn-outline-danger">
                                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Profile Modal -->
    <div class="modal fade" id="editProfileModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Profile</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="update_profile.php" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" class="form-control" name="username" value="<?= htmlspecialchars($user['username']) ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($user['email']) ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Mobile Number</label>
                            <input type="tel" class="form-control" name="mobile" value="<?= htmlspecialchars($user['mobile']) ?>">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Change Password Modal -->
    <div class="modal fade" id="changePasswordModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Change Password</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="change_password.php" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Current Password</label>
                            <input type="password" class="form-control" name="current_password" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password" class="form-control" name="new_password" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" name="confirm_password" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Password</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle password visibility
        const togglePassword = document.querySelector('#togglePassword');
        const passwordField = document.querySelector('#passwordField');
        
        togglePassword.addEventListener('click', function() {
            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    </script>
</body>
</html>