
<?php require_once 'includes/header.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Asset Details</title>
    <!-- Bootstrap CSS -->
</head>
<body>
<div class="container">
    <ol class="breadcrumb">
        <li><a href="dashboard.php">Home</a></li>
        <li class="active">Asset Details</li>
    </ol>
    <div class="container mt-5">
        <h2>Asset Details</h2>
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="page-heading"><i class="glyphicon glyphicon-edit"></i> Manage Asset</div>
            </div>
            <!-- /panel-heading -->
            <div class="panel-body">
                <div class="remove-messages"></div>
                <div class="div-action pull pull-right" style="padding-bottom:20px;">
                    <a href="addasset.php" style="text-decoration:none;"> <button class="btn btn-danger button1"> <i class="glyphicon glyphicon-plus-sign"></i> Add Asset </button></a>
                </div>
                <!-- /div-action -->
                <table class="table">
                    <thead>
                    <tr>
                        <th>Asset Name</th>
                        <th>Purchase Value</th>
                        <th>Asset Current Value</th>
                        <th>Last Update Date</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    // Database connection
                    $servername = "localhost"; // Change this if your database is hosted elsewhere
                    $username = "root";
                    $password = "";
                    $database = "finance";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $database);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Fetch data from database
                    $sql = "SELECT * FROM asset";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row['Asset_Name'] . "</td>";
                            echo "<td>INR " . $row['Purchase_Value'] . "</td>";
                            echo "<td>INR " . $row['Asset_Current_Value'] . "</td>";
                            echo "<td>" . $row['Last_Update_Date'] . "</td>";
                            echo "<td>
                                <a href='editasset.php?id=" . $row['Asset_ID'] . "' class='btn btn-primary btn-sm'>Edit</a>
                                <a href='deleteasset.php?id=" . $row['Asset_ID'] . "' class='btn btn-danger btn-sm'>Delete</a>
                              </td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No asset details found</td></tr>";
                    }

                    // Close connection
                    $conn->close();
                    ?>
                    </tbody>
					
					
					
                </table>
            </div>
            <!-- /panel-body -->
        </div>
        <!-- /panel -->
    </div>
    <!-- /container mt-5 -->
</div>
<!-- /container -->

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
