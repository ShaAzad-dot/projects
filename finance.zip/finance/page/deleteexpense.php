<?php
// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    $alertMessage = "Error: No expense ID provided.";
} else {
    // Database connection
    $servername = "localhost"; // Change this if your database is hosted elsewhere
    $username = "root";
    $password = "";
    $database = "finance";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        $alertMessage = "Connection failed: " . $conn->connect_error;
    } else {
        // Fetch expense details based on ID
        $id = $_GET['id'];
        $sql = "SELECT * FROM Expense WHERE ExpenseID = $id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Delete the expense entry
            $deleteSql = "DELETE FROM Expense WHERE ExpenseID = $id";
            if ($conn->query($deleteSql) === TRUE) {
                $alertMessage = "Expense entry deleted successfully.";
            } else {
                $alertMessage = "Error deleting expense entry: " . $conn->error;
            }
        } else {
            $alertMessage = "Error: Expense not found.";
        }

        // Close connection
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Expense</title>
    <!-- Bootstrap CSS or any other styling -->
</head>
<body>
    <script>
        // JavaScript to display alert dynamically after the page loads
        window.onload = function() {
            alert("<?php echo $alertMessage; ?>");
            window.history.back(); // Go back to the previous page
        };
    </script>
</body>
</html>