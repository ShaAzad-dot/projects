<?php 
require_once 'includes/header.php'; 

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$bankName = $accountNumber = $accountHolder = $minimumBalance = $availableBalance = $lastUpdateDate = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $bankName = $_POST["bank_name"];
    $accountNumber = $_POST["account_number"];
    $accountHolder = $_POST["account_holder"];
    $minimumBalance = $_POST["minimum_balance"];
    $availableBalance = $_POST["available_balance"];
    $lastUpdateDate = $_POST["last_update_date"];

    // Prepare and bind SQL statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO bank (bank_name, account_number, account_holder, minimum_balance, available_balance, last_update_date) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssdss", $bankName, $accountNumber, $accountHolder, $minimumBalance, $availableBalance, $lastUpdateDate);

    if ($stmt->execute()) {
        echo "<div class='container mt-3'><div class='alert alert-success'>New record created successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error: " . $stmt->error . "</div></div>";
    }

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Bank Details</title>
    <!-- Bootstrap CSS -->

</head>
<body>
    <div class="container mt-5">
        <ol class="breadcrumb">
            <li><a href="dashboard.php">Home</a></li>
            <li class="active"> Add Bank Details</li>
        </ol>
        <h2>Add Bank Details</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="bank_name">Bank Name:</label>
                <input type="text" class="form-control" id="bank_name" name="bank_name" required>
                <div class="invalid-feedback">Please enter the bank name.</div>
            </div>
            <div class="form-group">
                <label for="account_number">Account Number:</label>
                <input type="text" class="form-control" id="account_number" name="account_number" pattern="\d+" required>
                <div class="invalid-feedback">Please enter a valid account number.</div>
            </div>
            <div class="form-group">
                <label for="account_holder">Account Holder:</label>
                <input type="text" class="form-control" id="account_holder" name="account_holder" required>
                <div class="invalid-feedback">Please enter the account holder.</div>
            </div>
            <div class="form-group">
                <label for="minimum_balance">Minimum Balance:</label>
                <input type="number" class="form-control" id="minimum_balance" name="minimum_balance" required>
                <div class="invalid-feedback">Please enter the minimum balance.</div>
            </div>
            <div class="form-group">
                <label for="available_balance">Available Balance:</label>
                <input type="number" class="form-control" id="available_balance" name="available_balance" required>
                <div class="invalid-feedback">Please enter the available balance.</div>
            </div>
            <div class="form-group">
                <label for="last_update_date">Last Update Date:</label>
                <input type="date" class="form-control" id="last_update_date" name="last_update_date" required>
                <div class="invalid-feedback">Please enter the last update date.</div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-plus-sign"></i> Submit</button>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Form validation script -->
    <script>
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                var forms = document.getElementsByClassName('needs-validation');
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
    </script>
</body>
</html>
