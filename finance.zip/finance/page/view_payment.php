<?php
require_once 'includes/header.php';

$conn = new mysqli("localhost", "root", "", "finance");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$loanId = $_GET['loan_id'] ?? 0;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Payment History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <?php if($loanId): ?>
        <?php
        $loanInfo = $conn->query("SELECT * FROM loans WHERE loan_id = $loanId")->fetch_assoc();
        echo "<h3 class='mb-4'>Payment History for: {$loanInfo['loan_name']}</h3>";
        ?>
    <?php else: ?>
        <h3 class='mb-4'>All Loan Payments</h3>
    <?php endif; ?>
    
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">Payment Records</h4>
        </div>
        
        <div class="card-body">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr>
                        <?php if(!$loanId): ?>
                        <th>Loan Name</th>
                        <?php endif; ?>
                        <th>Amount</th>
                        <th>Payment Date</th>
                        <th>Month</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT p.*, l.loan_name 
                            FROM loan_payments p
                            JOIN loans l ON p.loan_id = l.id
                            ".($loanId ? "WHERE p.loan_id = $loanId" : "")."
                            ORDER BY p.payment_date DESC";
                    
                    $result = $conn->query($sql);
                    
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        if(!$loanId) echo "<td>{$row['loan_name']}</td>";
                        echo "<td>₹".number_format($row['amount'], 2)."</td>";
                        echo "<td>".date('d M Y', strtotime($row['payment_date']))."</td>";
                        echo "<td>".date('F Y', strtotime($row['month_year'].'-01'))."</td>";
                        echo "<td><span class='badge ".($row['status'] == 'paid' ? 'bg-success' : 'bg-danger')."'>".ucfirst($row['status'])."</span></td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
<?php $conn->close(); ?>