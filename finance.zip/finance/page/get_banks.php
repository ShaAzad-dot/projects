<?php
// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch bank names and their available balances
$sql = "SELECT bank_name, available_balance FROM bank";
$result = $conn->query($sql);

// Array to store bank data
$bank_data = array();

// Fetch bank data
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $bank_data[] = array(
            'name' => $row["bank_name"],
            'available_balance' => $row["available_balance"]
        );
    }
}

// Close connection
$conn->close();

// Return bank data as JSON
echo json_encode($bank_data);
?>
