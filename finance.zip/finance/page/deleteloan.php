
<?php
require_once 'includes/header.php';
// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    echo "Error: No card ID provided.";
    exit();
}

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch card details based on ID
$id = $_GET['id'];
$sql = "SELECT * FROM loans WHERE loan_id = $id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    echo "Error: Card not found.";
    exit();
}

// Delete card details
$deleteSql = "DELETE FROM loans WHERE loan_id = $id";

if ($conn->query($deleteSql) === TRUE) {
    echo "<div class='container mt-3'><div class='alert alert-success'>Record deleted successfully</div></div>";
} else {
    echo "<div class='container mt-3'><div class='alert alert-danger'>Error deleting record: " . $conn->error . "</div></div>";
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Credit Card</title>
    <!-- Bootstrap CSS -->
   
</head>
<body>
    <div class="container mt-5">
        <p><a href="manageloan.php" class="btn btn-secondary">Back to Credit Card Details</a></p>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
