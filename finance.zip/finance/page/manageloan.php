
<?php require_once 'includes/header.php'; ?>
<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if loan ID is provided
if(isset($_POST['loan_id'])) {
    $loan_id = $_POST['loan_id'];

    // Fetch loan details from database
    $sql = "SELECT emi_tenure, paid_emi FROM loans WHERE loan_id = $loan_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Calculate pending EMI based on emi tenure and paid EMI
        $emi_tenure = $row['emi_tenure'];
        $paid_emi = $row['paid_emi'];
        $pending_emi = $emi_tenure - $paid_emi;

        // Update loan record in the database with new pending and paid EMI counts
        $update_sql = "UPDATE loans SET paid_emi = $paid_emi + 1, pending_emi = $pending_emi - 1 WHERE loan_id = $loan_id";
        if ($conn->query($update_sql) === TRUE) {
            echo "Loan details updated successfully"; // Response indicating success
        } else {
            echo "Error updating loan details: " . $conn->error; // Response indicating failure
        }
    } else {
        echo "No loan found with ID: $loan_id"; // Response indicating no loan found
    }
} else {
    echo "Loan ID is not provided"; // Response indicating no loan ID provided
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Loan Details</title>
    <!-- Bootstrap CSS -->
</head>
<body>
<div class="container">
    <ol class="breadcrumb">
        <li><a href="dashboard.php">Home</a></li>		  
        <li class="active">Loan Details</li>
    </ol>
    <div class="container mt-5">
        <h2>Loan Details</h2>

        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="page-heading"> <i class="glyphicon glyphicon-edit"></i> Manage Loans</div>
            </div> <!-- /panel-heading -->
            <div class="panel-body">

                <div class="remove-messages"></div>

                <div class="div-action pull pull-right" style="padding-bottom:20px;">
                    <a href="addloan.php" style="text-decoration:none;"> <button class="btn btn-danger button1"> <i class="glyphicon glyphicon-plus-sign"></i>  Add Loan </button></a>
                </div> <!-- /div-action -->	

                <table class="table">
                    <thead>
                        <tr>
                            <th>Loan Name</th>
                            <th>Loan Type</th>
                            <th>Loan Owner</th>
                            <th>EMI Amount</th>
                            <th>Emi Tenure</th>
                            <th>EMI Date</th>
							<th>Paid EMI</th>
                            <th>Interest</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Database connection
                        $servername = "localhost"; // Change this if your database is hosted elsewhere
                        $username = "root";
                        $password = "";
                        $database = "finance";

                        // Create connection
                        $conn = new mysqli($servername, $username, $password, $database);

                        // Check connection
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        // Fetch data from database
                        $sql = "SELECT * FROM loans";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . $row['loan_name'] . "</td>";
                                echo "<td>" . $row['loan_type'] . "</td>";
								echo "<td>" . $row['loan_owner'] . "</td>";
								
								
                               
                                echo "<td>INR " . $row['emi_amount'] . "</td>";
                                echo "<td>" . $row['emi_tenure'] . " months</td>";
                                
                                echo "<td>" . $row['emi_date'] . "</td>";
                                echo "<td>" . $row['paid_emi'] . "</td>";
                                 
								 echo "<td>" . $row['interest'] . "</td>";
                               
                               
                              
                                echo "<td>
                                        <a href='editloan.php?id=" . $row['loan_id'] . "' class='btn btn-primary btn-sm'>Edit</a>
                                        <a href='deleteloan.php?id=" . $row['loan_id'] . "' class='btn btn-danger btn-sm'>Delete</a>
										
										 <a href='viewloan.php?id=" . $row['loan_id'] . "' class='btn btn-success btn-sm'>View </a>
										
										   
										
                                    </td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='13'>No loan details found</td></tr>";
                        }

                        // Close connection
                        $conn->close();
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
