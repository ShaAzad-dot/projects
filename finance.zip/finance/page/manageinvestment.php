<?php
// Include header file
require_once 'includes/header.php';

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from database
$sql = "SELECT * FROM Investments";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Investment Details</title>
    <!-- Bootstrap CSS -->
</head>
<body>
    <div class="container">
        <ol class="breadcrumb">
            <li><a href="dashboard.php">Home</a></li>		  
            <li class="active">Investment</li>
        </ol>
        <div class="container mt-5">
            <h2>Investment Details</h2>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div class="page-heading"> <i class="glyphicon glyphicon-edit"></i> Manage Investment</div>
                </div> <!-- /panel-heading -->
                <div class="panel-body">
                    <div class="remove-messages"></div>
                    <div class="div-action pull pull-right" style="padding-bottom:20px;">
                        <a href="addinvestment.php" style="text-decoration:none;"> <button class="btn btn-primary button1"> <i class="glyphicon glyphicon-plus-sign"></i>  Add Investment </button></a>
                    </div> <!-- /div-action -->	
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Investment Name</th>
                                <th>Investment Platform</th>
                                <th>Investment Type</th>
                                <th>Investment Frequency</th>
                                <th>Invested Amount</th>
                                <th>Profit/Loss</th>
                                <th>Last Updated Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . $row['InvestmentName'] . "</td>";
                                    echo "<td>" . $row['InvestmentPlatform'] . "</td>";
                                    echo "<td>" . $row['InvestmentType'] . "</td>";
                                    echo "<td>" . $row['InvestmentFrequency'] . "</td>";
                                    echo "<td>" . $row['InvestedAmount'] . "</td>";
                                    echo "<td>" . $row['ProfitLoss'] . "</td>";
                                    echo "<td>" . $row['LastUpdatedDate'] . "</td>";
                                    echo "<td>
                                            <a href='editinvestment.php?id=" . $row['InvestmentID'] . "' class='btn btn-primary btn-sm'>Edit</a>
                                            <a href='deleteinvestment.php?id=" . $row['InvestmentID'] . "' class='btn btn-danger btn-sm'>Delete</a>
                                          </td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='8'>No investment details found</td></tr>";
                            }

                            // Close connection
                            $conn->close();
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
