<!DOCTYPE html>
<html lang="en">
<head>
  <title>Finance Dashboard</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
      body {
          background-color: #f8f9fa;
      }
      .navbar {
          background: linear-gradient(45deg, #1a1a2e, #16213e);
          border-bottom: 3px solid #17a2b8;
          box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
      }
      .navbar-brand {
          color: white !important;
          font-weight: bold;
          font-size: 18px;
      }
      .navbar-nav > li > a {
          color: white !important;
          transition: all 0.3s;
      }
      .navbar-nav > li > a:hover {
          background-color: #17a2b8 !important;
          color: white !important;
          border-radius: 5px;
      }
      .dropdown-menu {
          background-color: #16213e;
      }
      .dropdown-menu > li > a {
          color: white !important;
          transition: all 0.3s;
      }
      .dropdown-menu > li > a:hover {
          background-color: #17a2b8 !important;
          border-radius: 5px;
      }
      .glyphicon {
          margin-right: 8px;
      }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">
        <?php
        session_start();
        if(isset($_SESSION['username'])) {
            echo "<b>Welcome, " . $_SESSION['username'] . "!</b>";
        } else {
            header("Location: login.php");
            exit();
        }
        ?>
      </a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li class="active"><a href="../page/dashboard.php"><i class="glyphicon glyphicon-th"></i> Dashboard</a></li>
      <li><a href="addcreditcard.php"><i class="glyphicon glyphicon-credit-card"></i> Credit Card</a></li>
      <li><a href="manageloan.php"><i class="glyphicon glyphicon-piggy-bank"></i> Loan</a></li>
      <li><a href="managedebt.php"><i class="glyphicon glyphicon-calendar"></i> Debt</a></li>
      <li><a href="manageexpense.php"><i class="glyphicon glyphicon-edit"></i> Expense</a></li>
      
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="glyphicon glyphicon-usd"></i> Savings <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="managebank.php"><i class="glyphicon glyphicon-piggy-bank"></i> Bank</a></li>
          <li><a href="manageinvestment.php"><i class="glyphicon glyphicon-bitcoin"></i> Investment</a></li>
          <li><a href="managecredit.php"><i class="glyphicon glyphicon-usd"></i> Credit</a></li>
          <li><a href="manageasset.php"><i class="glyphicon glyphicon-shopping-cart"></i> Asset</a></li>
          <li><a href="managecash.php"><i class="glyphicon glyphicon-credit-card"></i> Cash</a></li>
          <li><a href="manageincome.php"><i class="glyphicon glyphicon-usd"></i> Income</a></li>
        </ul>
      </li>
      <li><a href="managenotice.php"><i class="glyphicon glyphicon-check"></i> Notice</a></li>
      <li><a href="managereport.php"><i class="glyphicon glyphicon-file"></i> Report</a></li>
      
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="glyphicon glyphicon-ruble"></i> Bills <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="managebill.php"><i class="glyphicon glyphicon-cog"></i> Manage Bill</a></li>
          <li><a href="paidbill.php"><i class="glyphicon glyphicon-ok"></i> Paid Bills</a></li>
          <li><a href="unpaidbill.php"><i class="glyphicon glyphicon-remove"></i> Unpaid Bills</a></li>
        </ul>
      </li>
      
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="glyphicon glyphicon-user"></i> <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="profile.php"><i class="glyphicon glyphicon-file"></i> Profile</a></li>
          <li><a href="reset.php"><i class="glyphicon glyphicon-cog"></i> Settings</a></li>
          <li><a href=""><i class="glyphicon glyphicon-plus"></i> Add User</a></li>
          <li><a href="../page/logout.php"><i class="glyphicon glyphicon-off"></i> Logout</a></li>
        </ul>
      </li>
    </ul>
  </div>
</nav>

</body>
</html>
