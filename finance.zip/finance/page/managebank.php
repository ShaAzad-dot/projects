<?php require_once 'includes/header.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bank Details</title>
    <!-- Bootstrap CSS -->
</head>
<body>
<div class="container">
    <ol class="breadcrumb">
        <li><a href="dashboard.php">Home</a></li>
        <li class="active">Bank Details</li>
    </ol>
    <div class="container mt-5">
        <h2>Bank Details</h2>
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="page-heading"><i class="glyphicon glyphicon-edit"></i> Manage Bank</div>
            </div>
            <!-- /panel-heading -->
            <div class="panel-body">
                <div class="remove-messages"></div>
                <div class="div-action pull pull-right" style="padding-bottom:20px;">
                    <a href="addbank.php" style="text-decoration:none;"> <button class="btn btn-danger button1"> <i class="glyphicon glyphicon-plus-sign"></i> Add Bank </button></a>
                </div>
                <!-- /div-action -->
                <table class="table">
                    <thead>
                    <tr>
                        <th>Bank Name</th>
                        <th>Account Number</th>
                        <th>Account Holder</th>
                        <th>Minimum Balance</th>
                        <th>Available Balance</th>
                        <th>Last Update Date</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    // Database connection
                    $servername = "localhost"; // Change this if your database is hosted elsewhere
                    $username = "root";
                    $password = "";
                    $database = "finance";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $database);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Fetch data from database
                    $sql = "SELECT * FROM bank";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row['bank_name'] . "</td>";
                            echo "<td>" . $row['account_number'] . "</td>";
                            echo "<td>" . $row['account_holder'] . "</td>";
                            echo "<td>INR " . $row['minimum_balance'] . "</td>";
                            echo "<td>INR " . $row['available_balance'] . "</td>";
                            echo "<td>" . $row['last_update_date'] . "</td>";
                            echo "<td>
                                <a href='editbank.php?id=" . $row['id'] . "' class='btn btn-primary btn-sm'>Edit</a>
                                <a href='deletebank.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm'>Delete</a>
                              </td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7'>No bank details found</td></tr>";
                    }

                    // Close connection
                    $conn->close();
                    ?>
                    </tbody>
					
					
					
                </table>
            </div>
            <!-- /panel-body -->
        </div>
        <!-- /panel -->
    </div>
    <!-- /container mt-5 -->
</div>
<!-- /container -->

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
