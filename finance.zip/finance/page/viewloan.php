<?php
// Include header and database connection
require_once 'includes/header.php';

// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    echo "Error: No loan ID provided.";
    exit();
}

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch loan details based on ID
$id = $_GET['id'];
$sql = "SELECT * FROM loans WHERE loan_id = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // Assign loan details to variables
    $loanName = $row['loan_name'];
    $loanType = $row['loan_type'];
    $loanOwner = $row['loan_owner'];
    $principleAmount = $row['principle_amount'];
    $emiDate =$row['emi_date'];
    $emiAmount = $row['emi_amount'];
    $emiTenure = $row['emi_tenure'];
    $paidEmi = $row['paid_emi'];
    $pendingEmi = $row['pending_emi'];
    $totalAmount = $row['total_amount'];
    $totalPaidAmount = $row['paid_amount'];
    $totalPendingAmount = $row['pending_amount'];
    $interest = $row['interest'];
} else {
    echo "Error: Loan not found.";
    exit();
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Loan Details</title>
    <!-- Bootstrap CSS -->
    <!-- Include your Bootstrap CSS link here -->
</head>
<body>
    <div class="container mt-5">
		
		<ol class="breadcrumb">
<li><a href="dashboard.php">Home</a></li>		  
<li class="active">View Loan</li>
</ol>
		
		
		
		
		
		
		
		
		
        <h2>Loan Details</h2>
        <table class="table" style="font-weight:bolder;">
            <tr>
                <th>Loan Name:</th>
                <td><?php echo $loanName; ?></td>
            </tr>
            <tr>
                <th>Loan Type:</th>
                <td><?php echo $loanType; ?></td>
            </tr>
            <tr>
                <th>Loan Owner:</th>
                <td><?php echo $loanOwner; ?></td>
            </tr>
            <tr>
                <th>Principle Amount:</th>
                <td><?php echo $principleAmount; ?></td>
            </tr>
            <tr>
                <th>EMI Amount:</th>
                <td><?php echo $emiAmount; ?></td>
            </tr>
			
			
			  <tr>
                <th>EMI Date:</th>
                <td><?php echo $emiDate; ?></td>
            </tr>
			
			
            <tr>
                <th>EMI Tenure (months):</th>
                <td><?php echo $emiTenure; ?></td>
            </tr>
            <tr>
                <th>Paid EMI:</th>
                <td style="color:green;"><?php echo $paidEmi; ?></td>
            </tr>
            <tr>
                <th>Pending EMI:</th>
                <td><?php echo $pendingEmi; ?></td>
            </tr>
            <tr>
                <th>Total Amount:</th>
                <td><?php echo $totalAmount; ?></td>
            </tr>
            <tr>
                <th>Total Paid Amount:</th>
                <td style="color:green;"><?php echo $totalPaidAmount; ?></td>
            </tr>
            <tr>
                <th>Total Pending Amount:</th>
                <td><?php echo $totalPendingAmount; ?></td>
            </tr>
            <tr>
                <th>Interest:</th>
                <td style="color:red;"><?php echo $interest; ?></td>
            </tr>
           
        </table>
        
		<a href="manageloan.php"><button class="btn btn-primary">Loan List</button></a>
    
    </div>

    <!-- Bootstrap JS and dependencies -->
    <!-- Include your Bootstrap JS and dependencies here -->
</body>
</html>
