<?php
require_once 'includes/header.php'; 

// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    echo "Error: No cash ID provided.";
    exit();
}

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch cash details based on ID
$id = $_GET['id'];
$sql = "SELECT * FROM cash WHERE id = $id"; // Updated to use the correct column name
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Error: Cash details not found.";
    exit();
}

// Delete cash record
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $deleteSql = "DELETE FROM cash WHERE id= $id"; // Updated to use the correct column name

    if ($conn->query($deleteSql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>Record deleted successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error deleting record: " . $conn->error . "</div></div>";
    }
}

// Close connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Cash Record</title>
    <!-- Bootstrap CSS -->
</head>
<body>
    <div class="container mt-5">
        <h2>Delete Cash Record</h2>
        <p>Are you sure you want to delete the cash record?</p>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $id; ?>">
            <button type="submit" class="btn btn-danger">Delete</button>
            <a href="cash_details.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
