<?php
require_once 'includes/header.php'; 

// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    echo "Error: No investment ID provided.";
    exit();
}

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch investment details based on ID
$id = $_GET['id'];
$sql = "SELECT * FROM Investments WHERE InvestmentID = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Error: Investment not found.";
    exit();
}

// Initialize variables with current data
$investmentName = $row['InvestmentName'];
$investmentPlatform = $row['InvestmentPlatform'];
$investmentType = $row['InvestmentType'];
$investmentFrequency = $row['InvestmentFrequency'];
$investedAmount = $row['InvestedAmount'];
$profitLoss = $row['ProfitLoss'];
$lastUpdatedDate = $row['LastUpdatedDate'];

// Update investment details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $investmentName = $_POST["investment_name"];
    $investmentPlatform = $_POST["investment_platform"];
    $investmentType = $_POST["investment_type"];
    $investmentFrequency = $_POST["investment_frequency"];
    $investedAmount = $_POST["invested_amount"];
    $profitLoss = $_POST["profit_loss"];
    $lastUpdatedDate = $_POST["last_updated_date"];

    $updateSql = "UPDATE Investments SET 
                    InvestmentName='$investmentName', 
                    InvestmentPlatform='$investmentPlatform', 
                    InvestmentType='$investmentType', 
                    InvestmentFrequency='$investmentFrequency', 
                    InvestedAmount='$investedAmount', 
                    ProfitLoss='$profitLoss', 
                    LastUpdatedDate='$lastUpdatedDate' 
                  WHERE InvestmentID=$id";

    if ($conn->query($updateSql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>Record updated successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error updating record: " . $conn->error . "</div></div>";
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Investment Details</title>
    <!-- Bootstrap CSS -->
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Investment Details</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $id; ?>" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="investment_name">Investment Name:</label>
                <input type="text" class="form-control" id="investment_name" name="investment_name" value="<?php echo $investmentName; ?>" required>
                <div class="invalid-feedback">Please enter the investment name.</div>
            </div>
            <div class="form-group">
                <label for="investment_platform">Investment Platform:</label>
                <input type="text" class="form-control" id="investment_platform" name="investment_platform" value="<?php echo $investmentPlatform; ?>" required>
                <div class="invalid-feedback">Please enter the investment platform.</div>
            </div>
            <div class="form-group">
                <label for="investment_type">Investment Type:</label>
                <input type="text" class="form-control" id="investment_type" name="investment_type" value="<?php echo $investmentType; ?>" required>
                <div class="invalid-feedback">Please enter the investment type.</div>
            </div>
            <div class="form-group">
                <label for="investment_frequency">Investment Frequency:</label>
                <input type="text" class="form-control" id="investment_frequency" name="investment_frequency" value="<?php echo $investmentFrequency; ?>" required>
                <div class="invalid-feedback">Please enter the investment frequency.</div>
            </div>
            <div class="form-group">
                <label for="invested_amount">Invested Amount:</label>
                <input type="text" class="form-control" id="invested_amount" name="invested_amount" value="<?php echo $investedAmount; ?>" required>
                <div class="invalid-feedback">Please enter the invested amount.</div>
            </div>
            <div class="form-group">
                <label for="profit_loss">Profit/Loss:</label>
                <input type="text" class="form-control" id="profit_loss" name="profit_loss" value="<?php echo $profitLoss; ?>">
            </div>
            <div class="form-group">
                <label for="last_updated_date">Last Updated Date:</label>
                <input type="date" class="form-control" id="last_updated_date" name="last_updated_date" value="<?php echo $lastUpdatedDate; ?>" required>
                <div class="invalid-feedback">Please enter the last updated date.</div>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="investment_details.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Form validation script -->
    <script>
        // JavaScript for form validation
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();

        // Function to update utilized limit in real time
        function updateUtilizedLimit() {
            var totalLimit = parseFloat(document.getElementById('total_limit').value);
            var availableLimit = parseFloat(document.getElementById('available_limit').value);
            var utilizedLimit = totalLimit - availableLimit;
            document.getElementById('utilized_limit').value = utilizedLimit.toFixed(2);
        }

        // Attach event listeners to total limit and available limit inputs
        document.getElementById('total_limit').addEventListener('input', updateUtilizedLimit);
        document.getElementById('available_limit').addEventListener('input', updateUtilizedLimit);

        // Call the function initially to populate utilized limit
        updateUtilizedLimit();
    </script>
</body>
</html>
