
<?php
require_once 'includes/header.php';

// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    echo "Error: No asset ID provided.";
    exit();
}

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch asset details based on ID
$id = $_GET['id'];
$sql = "SELECT * FROM asset WHERE Asset_ID = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Error: Asset not found.";
    exit();
}

// Initialize variables with current data
$assetName = $row['Asset_Name'];
$purchaseValue = $row['Purchase_Value'];
$currentValue = $row['Asset_Current_Value'];
$lastUpdateDate = $row['Last_Update_Date'];

// Update asset details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $assetName = $_POST["asset_name"];
    $purchaseValue = $_POST["purchase_value"];
    $currentValue = $_POST["current_value"];
    $lastUpdateDate = $_POST["last_update_date"];

    $updateSql = "UPDATE asset SET Asset_Name='$assetName', Purchase_Value='$purchaseValue', Asset_Current_Value='$currentValue', Last_Update_Date='$lastUpdateDate' WHERE Asset_ID=$id";

    if ($conn->query($updateSql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>Record updated successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error updating record: " . $conn->error . "</div></div>";
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Asset Details</title>
    <!-- Bootstrap CSS -->
</head>
<body>
<div class="container mt-5">
    <h2>Edit Asset Details</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $id; ?>" class="needs-validation" novalidate>
        <div class="form-group">
            <label for="asset_name">Asset Name:</label>
            <input type="text" class="form-control" id="asset_name" name="asset_name" value="<?php echo $assetName; ?>" required>
            <div class="invalid-feedback">Please enter the asset name.</div>
        </div>
        <div class="form-group">
            <label for="purchase_value">Purchase Value:</label>
            <input type="text" class="form-control" id="purchase_value" name="purchase_value" value="<?php echo $purchaseValue; ?>" required>
            <div class="invalid-feedback">Please enter the purchase value.</div>
        </div>
        <div class="form-group">
            <label for="current_value">Current Value:</label>
            <input type="text" class="form-control" id="current_value" name="current_value" value="<?php echo $currentValue; ?>" required>
            <div class="invalid-feedback">Please enter the current value.</div>
        </div>
        <div class="form-group">
            <label for="last_update_date">Last Update Date:</label>
            <input type="date" class="form-control" id="last_update_date" name="last_update_date" value="<?php echo $lastUpdateDate; ?>" required>
            <div class="invalid-feedback">Please select the last update date.</div>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="asset_details.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- Form validation script -->
<script>
    // JavaScript for form validation
    (function() {
        'use strict';
        window.addEventListener('load', function() {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName('needs-validation');
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();
</script>
</body>
</html>
