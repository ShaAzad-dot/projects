
<?php require_once 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Debt Details</title>
    <!-- Bootstrap CSS -->
</head>
<body>
	<div class="container">
		<ol class="breadcrumb">
			<li><a href="dashboard.php">Home</a></li>		  
			<li class="active">Debt Details</li>
		</ol>
		<div class="container mt-5">
			<h2>Debt Details</h2>
			<div class="panel panel-default">
				<div class="panel-heading">
					<div class="page-heading"> <i class="glyphicon glyphicon-edit"></i> Manage Debt Details</div>
				</div>
				<div class="panel-body">
					<div class="remove-messages"></div>
					<div class="div-action pull pull-right" style="padding-bottom:20px;">
						<a href="adddebt.php" style="text-decoration:none;">
							<button class="btn btn-danger button1"> <i class="glyphicon glyphicon-plus-sign"></i>  Add Debt </button>
						</a>
					</div>
					<table class="table">
						<thead>
							<tr>
								<th>Creditor Name</th>
								<th>Creditor Amount</th>
								<th>Tenure</th>
								<th>Pending Amount</th>
								<th>Paid Amount</th>
								<th>Payoff Date</th>
								<th>Actions</th>
							</tr>
						</thead>
						<tbody>
							<?php
							// Database connection
							$servername = "localhost"; // Change this if your database is hosted elsewhere
							$username = "root";
							$password = "";
							$database = "finance";

							// Create connection
							$conn = new mysqli($servername, $username, $password, $database);

							// Check connection
							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							}

							// Fetch data from database
							$sql = "SELECT * FROM debt_details";
							$result = $conn->query($sql);

							if ($result->num_rows > 0) {
								while ($row = $result->fetch_assoc()) {
									echo "<tr>";
									echo "<td>" . $row['creditor_name'] . "</td>";
									echo "<td>INR " . $row['creditor_amount'] . "</td>";
									echo "<td>" . $row['tenure'] . "</td>";
									echo "<td>INR " . $row['pending_amount'] . "</td>";
									echo "<td>INR " . $row['paid_amount'] . "</td>";
									echo "<td>" . $row['payoff_date'] . "</td>";
									echo "<td>
											<a href='editdebt.php?id=" . $row['id'] . "' class='btn btn-primary btn-sm'>Edit</a>
											<a href='deletedebt.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm'>Delete</a>
										  </td>";
									echo "</tr>";
								}
							} else {
								echo "<tr><td colspan='7'>No debt details found</td></tr>";
							}

							// Close connection
							$conn->close();
							?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
