<?php
header('Content-Type: application/json');

// Database connection
$conn = new mysqli("localhost", "root", "", "finance");
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'DB connection failed: ' . $conn->connect_error]));
}

// Get input data with validation
$loanId = isset($_POST['loan_id']) ? intval($_POST['loan_id']) : 0;
$paymentDate = $_POST['payment_date'] ?? date('Y-m-d');
$monthYear = $_POST['month_year'] ?? date('Y-m');
$amount = isset($_POST['amount']) ? floatval($_POST['amount']) : 0;

// Validate inputs
if ($loanId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid loan ID']);
    exit;
}

if (!strtotime($paymentDate)) {
    echo json_encode(['success' => false, 'message' => 'Invalid payment date']);
    exit;
}

// Start transaction for data consistency
$conn->begin_transaction();

try {
    // Check if payment already exists for this month
    $check = $conn->prepare("SELECT * FROM loan_payments 
                           WHERE loan_id = ? AND month_year = ?");
    $check->bind_param("is", $loanId, $monthYear);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        // Update existing payment
        $update = $conn->prepare("UPDATE loan_payments SET 
                                payment_date = ?,
                                status = 'paid',
                                amount = ?
                                WHERE loan_id = ? AND month_year = ?");
        $update->bind_param("sdis", $paymentDate, $amount, $loanId, $monthYear);
        $update->execute();
    } else {
        // Insert new payment
        $insert = $conn->prepare("INSERT INTO loan_payments 
                                (loan_id, payment_date, amount, status, month_year)
                                VALUES (?, ?, ?, 'paid', ?)");
        $insert->bind_param("isds", $loanId, $paymentDate, $amount, $monthYear);
        $insert->execute();
    }

    // Update loan pending counts if needed
    $updateLoan = $conn->prepare("UPDATE loans SET 
                                pending_emi = pending_emi - 1,
                                pending_amount = pending_amount - ?,
                                paid_amount = paid_amount + ?
                                WHERE id = ? AND pending_emi > 0");
    $updateLoan->bind_param("ddi", $amount, $amount, $loanId);
    $updateLoan->execute();

    // Commit transaction
    $conn->commit();

    echo json_encode([
        'success' => true, 
        'message' => 'Payment recorded successfully',
        'data' => [
            'loan_id' => $loanId,
            'payment_date' => $paymentDate,
            'amount' => $amount,
            'month_year' => $monthYear
        ]
    ]);

} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    echo json_encode([
        'success' => false, 
        'message' => 'Error processing payment: ' . $e->getMessage()
    ]);
}

$conn->close();
?>