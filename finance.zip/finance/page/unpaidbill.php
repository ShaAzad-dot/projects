<?php 
require_once 'includes/header.php';

// Database connection with error handling
$conn = new mysqli("localhost", "root", "", "finance");
if ($conn->connect_error) {
    die("<div class='alert alert-danger'>Connection failed: " . $conn->connect_error . "</div>");
}

// Get current date for overdue calculation
$currentDate = date('Y-m-d');
$currentMonthYear = date('Y-m');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unpaid Bills</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --light-bg: #f8f9fa;
        }
        
        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .unpaid-bills-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
            padding: 25px;
            margin-top: 20px;
        }
        
        .table th {
            background-color: var(--primary-color);
            color: white;
            vertical-align: middle;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .status-unpaid {
            background-color: var(--danger-color);
            color: white;
        }
        
        .hover-effect:hover {
            background-color: rgba(220, 53, 69, 0.05);
            transition: all 0.3s ease;
        }
        
        .amount-cell {
            font-weight: 600;
        }
        
        .no-data {
            text-align: center;
            padding: 30px;
            color: #6c757d;
        }
        
        .overdue {
            background-color: rgba(220, 53, 69, 0.1);
        }
        
        .due-soon {
            background-color: rgba(255, 193, 7, 0.1);
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="unpaid-bills-container">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i> Unpaid Bills</h2>
                <div>
                    <a href="manage_bills.php" class="btn btn-primary me-2">
                        <i class="fas fa-arrow-left me-2"></i>Back to Bills
                    </a>
                    <a href="paidbills.php" class="btn btn-success">
                        <i class="fas fa-file-invoice-dollar me-2"></i>View Paid Bills
                    </a>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th class="text-center"><i class="fas fa-file-signature me-2"></i>Loan Name</th>
                            <th class="text-center"><i class="fas fa-rupee-sign me-2"></i>EMI Amount</th>
                            <th class="text-center"><i class="far fa-calendar-alt me-2"></i>Due Date</th>
                            <th class="text-center"><i class="fas fa-bell me-2"></i>Alert</th>
                            <th class="text-center"><i class="fas fa-cog me-2"></i>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Get loans that don't have a payment record for current month
                        $sql = "SELECT l.id, l.loan_name, l.emi_amount, l.emi_date 
                                FROM loans l
                                LEFT JOIN loan_payments p ON l.id = p.loan_id AND p.month_year = '$currentMonthYear'
                                WHERE p.loan_id IS NULL
                                ORDER BY l.emi_date ASC";
                        
                        $result = $conn->query($sql);
                        
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $dueDate = $row['emi_date'];
                                $isOverdue = $dueDate < $currentDate;
                                $isDueSoon = $dueDate <= date('Y-m-d', strtotime('+7 days')) && !$isOverdue;
                                
                                $rowClass = $isOverdue ? 'overdue' : ($isDueSoon ? 'due-soon' : '');
                                $alertText = $isOverdue ? 'Overdue' : ($isDueSoon ? 'Due Soon' : 'Pending');
                                $alertClass = $isOverdue ? 'bg-danger' : ($isDueSoon ? 'bg-warning text-dark' : 'bg-secondary');
                                
                                echo "<tr class='hover-effect $rowClass'>";
                                echo "<td class='text-center align-middle'>" . htmlspecialchars($row["loan_name"]) . "</td>";
                                echo "<td class='text-center align-middle amount-cell'>₹" . number_format($row["emi_amount"], 2) . "</td>";
                                echo "<td class='text-center align-middle'>" . date('d M Y', strtotime($row["emi_date"])) . "</td>";
                                echo "<td class='text-center align-middle'><span class='badge $alertClass'>$alertText</span></td>";
                                echo "<td class='text-center align-middle'>
                                        <button class='btn btn-sm btn-success mark-paid' data-loan-id='{$row['id']}'>
                                            <i class='fas fa-check-circle me-1'></i>Mark Paid
                                        </button>
                                      </td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5'>";
                            echo "<div class='no-data'>";
                            echo "<i class='fas fa-check-circle fa-3x mb-3 text-success'></i>";
                            echo "<h4>No Unpaid Bills Found</h4>";
                            echo "<p>All current bills are paid</p>";
                            echo "</div>";
                            echo "</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <?php if ($result->num_rows > 0): ?>
            <div class="mt-3">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    <strong>Total Unpaid:</strong> <?php echo $result->num_rows; ?> bills | 
                    <span class="text-danger"><i class="fas fa-exclamation-circle me-1"></i>Overdue</span> | 
                    <span class="text-warning"><i class="fas fa-exclamation-triangle me-1"></i>Due Soon</span>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    $(document).ready(function() {
        $('.mark-paid').click(function() {
            const loanId = $(this).data('loan-id');
            const paymentDate = prompt("Enter payment date (YYYY-MM-DD):", "<?= date('Y-m-d') ?>");
            
            if(paymentDate) {
                $.post('update_payment.php', {
                    loan_id: loanId,
                    payment_date: paymentDate,
                    month_year: "<?= $currentMonthYear ?>",
                    amount: $(this).closest('tr').find('.amount-cell').text().replace('₹','').replace(',','')
                }, function(response) {
                    if(response.success) {
                        location.reload();
                    } else {
                        alert('Error: ' + response.message);
                    }
                }, 'json');
            }
        });
    });
    </script>
</body>
</html>
<?php
$conn->close();
?>