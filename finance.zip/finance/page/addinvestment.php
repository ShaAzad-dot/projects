<?php
// Include header file
require_once 'includes/header.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Investment Details</title>
    <!-- Bootstrap CSS -->
  
</head>
<body>
    <div class="container mt-5">
		<ol class="breadcrumb">
            <li><a href="dashboard.php">Home</a></li>		  
            <li class="active"> Add Investment</li>
        </ol>
        <h2>Add Investment Details</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="investment_name">Investment Name:</label>
                <input type="text" class="form-control" id="investment_name" name="investment_name" required>
                <div class="invalid-feedback">Please enter the investment name.</div>
            </div>
            <div class="form-group">
                <label for="investment_platform">Investment Platform:</label>
                <input type="text" class="form-control" id="investment_platform" name="investment_platform" required>
                <div class="invalid-feedback">Please enter the investment platform.</div>
            </div>
            <div class="form-group">
                <label for="investment_type">Investment Type:</label>
                <input type="text" class="form-control" id="investment_type" name="investment_type" required>
                <div class="invalid-feedback">Please enter the investment type.</div>
            </div>
            <div class="form-group">
                <label for="investment_frequency">Investment Frequency:</label>
                <input type="text" class="form-control" id="investment_frequency" name="investment_frequency" required>
                <div class="invalid-feedback">Please enter the investment frequency.</div>
            </div>
            <div class="form-group">
                <label for="invested_amount">Invested Amount:</label>
                <input type="text" class="form-control" id="invested_amount" name="invested_amount" required>
                <div class="invalid-feedback">Please enter the invested amount.</div>
            </div>
            <div class="form-group">
                <label for="profit_loss">Profit/Loss:</label>
                <input type="text" class="form-control" id="profit_loss" name="profit_loss">
            </div>
            <div class="form-group">
                <label for="last_updated_date">Last Updated Date:</label>
                <input type="date" class="form-control" id="last_updated_date" name="last_updated_date" required>
                <div class="invalid-feedback">Please enter the last updated date.</div>
            </div>
            <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-plus-sign"></i>   Submit</button>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Form validation script -->
    <script>
        // JavaScript for form validation
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
    </script>
</body>
</html>


<?php
// Include header file
require_once 'includes/header.php';

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables to store form data
$investmentName = $investmentPlatform = $investmentType = $investmentFrequency = $investedAmount = $profitLoss = $lastUpdatedDate = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $investmentName = $_POST["investment_name"];
    $investmentPlatform = $_POST["investment_platform"];
    $investmentType = $_POST["investment_type"];
    $investmentFrequency = $_POST["investment_frequency"];
    $investedAmount = $_POST["invested_amount"];
    $profitLoss = isset($_POST["profit_loss"]) ? $_POST["profit_loss"] : 0;
    $lastUpdatedDate = $_POST["last_updated_date"];

    // SQL to insert data into table
    $sql = "INSERT INTO Investments (InvestmentName, InvestmentPlatform, InvestmentType, InvestmentFrequency, InvestedAmount, ProfitLoss, LastUpdatedDate)
            VALUES ('$investmentName', '$investmentPlatform', '$investmentType', '$investmentFrequency', '$investedAmount', '$profitLoss', '$lastUpdatedDate')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>New record created successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error: " . $sql . "<br>" . $conn->error . "</div></div>";
    }
}

// Close connection
$conn->close();
?>
