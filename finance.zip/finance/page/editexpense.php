
<?php
require_once 'includes/header.php'; 

// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    echo "Error: No expense ID provided.";
    exit();
}

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch expense details based on ID
$id = $_GET['id'];
$sql = "SELECT * FROM Expense WHERE ExpenseID = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Error: Expense not found.";
    exit();
}

// Initialize variables with current data
$name = $row['Name'];
$category = $row['Category'];
$amount = $row['Amount'];
$date = $row['Date'];
$bank = $row['Bank'];
$bill = $row['Bill'];
$others = $row['Others'];

// Update expense details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $category = $_POST["category"];
    $amount = $_POST["amount"];
    $date = $_POST["date"];
    $bank = $_POST["bank"];
    $bill = $_POST["bill"];
    $others = $_POST["others"];

    // Fetch old amount from database
    $oldAmountSql = "SELECT Amount FROM Expense WHERE ExpenseID=$id";
    $oldAmountResult = $conn->query($oldAmountSql);
    $oldAmountRow = $oldAmountResult->fetch_assoc();
    $oldAmount = $oldAmountRow['Amount'];

    // Calculate the difference in expense amount
    $amountDifference = $amount + $oldAmount;

    // Update expense record
    $updateSql = "UPDATE Expense SET Name='$name', Category='$category', Amount='$amount', Date='$date', Bank='$bank', Bill='$bill', Others='$others' WHERE ExpenseID=$id";

    if ($conn->query($updateSql) === TRUE) {
        // Update the bank's available balance
        $updateBankSql = "UPDATE bank SET available_balance = available_balance + $amountDifference WHERE bank_name = '$bank'";
        if ($conn->query($updateBankSql) !== TRUE) {
            echo "Error updating bank balance: " . $conn->error;
            exit;
        }

        echo "<div class='container mt-3'><div class='alert alert-success'>Record updated successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error updating record: " . $conn->error . "</div></div>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Expense</title>
    <!-- Bootstrap CSS -->
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Expense</h2>
		<div id="available_balance"></div>
<div id="new_available_balance"></div>

        <form id="expenseForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $id; ?>" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>" required>
                <div class="invalid-feedback">Please enter the name.</div>
            </div>
            <div class="form-group">
                <label for="category">Category:</label>
                <input type="text" class="form-control" id="category" name="category" value="<?php echo $category; ?>" required>
                <div class="invalid-feedback">Please enter the category.</div>
            </div>
            <div class="form-group">
                <label for="amount">Amount:</label>
                <input type="number" class="form-control" id="amount" name="amount" value="<?php echo $amount; ?>" required>
                <div class="invalid-feedback">Please enter the amount.</div>
            </div>
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" class="form-control" id="date" name="date" value="<?php echo $date; ?>" required>
                <div class="invalid-feedback">Please enter the date.</div>
            </div>
           
            <div class="form-group">
                <label for="bank">Amount Debited From:</label>
                <select class="form-control" id="bank" name="bank" required>
                    <option value="" disabled>Select Bank</option>
                    <?php
                    // Fetching bank data from the database
                    $sql = "SELECT bank_name, available_balance FROM bank";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            $selected = ($row['bank_name'] == $bank) ? 'selected' : '';
                            echo "<option value='" . $row['bank_name'] . "' $selected>" . $row['bank_name'] . " (Available Balance: INR " . $row['available_balance'] . ")</option>";
                        }
                    } else {
                        echo "<option value='' disabled>No banks found</option>";
                    }
                    ?>
                </select>
                <div class="invalid-feedback">Please select a bank.</div>
            </div>

            <div class="form-group">
                <label for="bill">Expense Paid For Which Bill:</label>
                <select class="form-control" id="bill" name="bill" required>
                    <option value="" disabled>Select a Bill</option>
                    <?php
                    // Fetching loan data from the database
                    $sql = "SELECT loan_name, emi_amount FROM loans";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            $selected = ($row['loan_name'] == $bill) ? 'selected' : '';
                            echo "<option value='" . $row['loan_name'] . "' $selected>" . $row['loan_name'] . " (EMI Amount: INR " . $row['emi_amount'] . ")</option>";
                        }
                    } else {
                        echo "<option value='' disabled>No bills found</option>";
                    }
                    ?>
                </select>
                <div class="invalid-feedback">Please select a bill.</div>
            </div>

            <div class="form-group">
                <label for="others">Others:</label>
                <textarea class="form-control" id="others" name="others" rows="3"><?php echo $others; ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="expense_list.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Form validation script -->
    <script>
        // JavaScript for form validation
      // JavaScript for form validation
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();

        // Function to update available balance based on the selected bank and expense amount
        function updateAvailableBalance() {
            var bankSelect = document.getElementById('bank');
            var amountInput = document.getElementById('amount');
            var selectedBank = bankSelect.value;
            var expenseAmount = parseFloat(amountInput.value);

            // Fetch the selected bank's available balance using AJAX
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'get_available_balance.php?bank=' + selectedBank, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var availableBalance = parseFloat(xhr.responseText);
                    if (!isNaN(availableBalance)) {
                        // Update the available balance display
                        document.getElementById('available_balance').innerText = 'Available Balance: INR ' + availableBalance.toFixed(2);

                        // Calculate and display the new available balance after deducting the expense amount
                        var newAvailableBalance = availableBalance - expenseAmount;
                        document.getElementById('new_available_balance').innerText = 'New Available Balance: INR ' + newAvailableBalance.toFixed(2);
                    } else {
                        // Handle error if available balance is not returned
                        console.error('Error: Unable to fetch available balance for ' + selectedBank);
                    }
                }
            };
            xhr.send();
        }

        // Add event listener to the amount input field
        document.getElementById('amount').addEventListener('input', updateAvailableBalance);
    </script>
	
</body>
</html>

           