<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the required fields are set
    if (isset($_POST['loan_id']) && isset($_POST['status']) && isset($_POST['paid_date'])) {
        // Get the submitted data
        $loan_id = $_POST['loan_id'];
        $status = $_POST['status'];
        $paid_date = $_POST['paid_date'];
        
        // Connect to your database
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "finance";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Check if the status is valid ('paid' or 'unpaid')
        if ($status === 'paid' || $status === 'unpaid') {
            // Update the payment status in the database
            $update_sql = "UPDATE loans SET status = '$status', paid_date = '$paid_date' WHERE loan_id = $loan_id";
            if ($conn->query($update_sql) === TRUE) {
                echo "Payment status updated successfully.";
            } else {
                echo "Error updating payment status: " . $conn->error;
            }
        } else {
            echo "Invalid payment status.";
        }

        // Close connection
        $conn->close();
    } else {
        echo "Missing required fields.";
    }
} else {
    echo "Invalid request.";
}
?>
