<?php 
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if header exists
$header_path = 'includes/header.php';
if (!file_exists($header_path)) {
    die("<div class='alert alert-danger'>Error: Header file not found</div>");
}

include_once $header_path;

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "finance";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("<div class='alert alert-danger'>Connection failed: " . $conn->connect_error . "</div>");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loan Management Report</title>
    <!-- Bootstrap CSS -->
 
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --danger-color: #e74c3c;
            --success-color: #27ae60;
            --warning-color: #f39c12;
            --light-bg: #f8f9fa;
        }
        
        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .report-section {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            overflow: hidden;
        }
        
        .section-header {
            background-color: var(--primary-color);
            color: white;
            padding: 15px 20px;
            font-weight: 600;
        }
        
        .ai-recommendation {
            border-left: 4px solid var(--secondary-color);
            background-color: rgba(52, 152, 219, 0.1);
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 0 4px 4px 0;
        }
        
        .priority-1 { border-left-color: var(--danger-color); background-color: rgba(231, 76, 60, 0.1); }
        .priority-2 { border-left-color: var(--warning-color); background-color: rgba(243, 156, 18, 0.1); }
        .priority-3 { border-left-color: var(--success-color); background-color: rgba(39, 174, 96, 0.1); }
        
        .table th {
            background-color: var(--primary-color);
            color: white;
        }
        
        .badge-priority {
            font-size: 0.8em;
            padding: 5px 8px;
            border-radius: 12px;
        }
        
        .priority-1-badge { background-color: var(--danger-color); }
        .priority-2-badge { background-color: var(--warning-color); }
        .priority-3-badge { background-color: var(--success-color); }
        
        .hover-effect:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        
        .cursor-pointer {
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <h1 class="text-center mb-4"><i class="fas fa-chart-pie me-2"></i> Loan Management Report</h1>
        
        <!-- AI Recommendation Section -->
        <div class="report-section hover-effect">
            <div class="section-header">
                <i class="fas fa-robot me-2"></i> AI-Powered Loan Repayment Strategy
            </div>
            <div class="p-4">
                <?php
                // Get all loans for analysis
                $loans = [];
                $result = $conn->query("SELECT * FROM loans");
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $loans[] = $row;
                    }
                }
                
                // AI Analysis Function
                function analyzeLoans($loans) {
                    $recommendations = [];
                    
                    foreach ($loans as $loan) {
                        $priority = 3; // Default priority (low)
                        $reason = "";
                        
                        // Calculate urgency score (weighted factors)
                        $urgencyScore = 0;
                        $urgencyScore += $loan['pending_emi'] * 0.4;
                        $urgencyScore += $loan['emi_amount'] * 0.3;
                        $urgencyScore += $loan['interest'] * 0.3;
                        
                        // Determine priority
                        if ($urgencyScore > 70) {
                            $priority = 1;
                            $reason = "High urgency due to combination of pending EMIs, high EMI amount, and interest";
                        } elseif ($urgencyScore > 40) {
                            $priority = 2;
                            $reason = "Medium urgency - consider paying soon";
                        } else {
                            $priority = 3;
                            $reason = "Low urgency - can be paid later";
                        }
                        
                        // Special case for loans almost completed
                        if ($loan['pending_emi'] < 3 && $loan['pending_emi'] > 0) {
                            $priority = 1;
                            $reason = "High priority - only ".$loan['pending_emi']." EMIs left to complete this loan";
                        }
                        
                        // Special case for high interest loans
                        if ($loan['interest'] > ($loan['emi_amount'] * 0.3)) {
                            $priority = 1;
                            $reason = "High priority - this loan has significantly high interest charges";
                        }
                        
                        $recommendations[] = [
                            'loan' => $loan,
                            'priority' => $priority,
                            'reason' => $reason,
                            'urgency_score' => $urgencyScore
                        ];
                    }
                    
                    // Sort by priority and urgency score
                    usort($recommendations, function($a, $b) {
                        if ($a['priority'] == $b['priority']) {
                            return $b['urgency_score'] <=> $a['urgency_score'];
                        }
                        return $a['priority'] <=> $b['priority'];
                    });
                    
                    return $recommendations;
                }
                
                // Get recommendations
                $recommendations = analyzeLoans($loans);
                
                if (!empty($recommendations)) {
                    echo '<div class="mb-4">';
                    echo '<h4><i class="fas fa-lightbulb me-2"></i> Recommended Repayment Order</h4>';
                    echo '<p>Based on your loan portfolio analysis, here\'s the optimal repayment sequence:</p>';
                    
                    // Display priority legend
                    echo '<div class="d-flex mb-3 gap-2">';
                    echo '<span class="badge priority-1-badge">High Priority</span>';
                    echo '<span class="badge priority-2-badge">Medium Priority</span>';
                    echo '<span class="badge priority-3-badge">Low Priority</span>';
                    echo '</div>';
                    
                    foreach ($recommendations as $rec) {
                        $loan = $rec['loan'];
                        echo '<div class="ai-recommendation priority-'.$rec['priority'].' mb-3">';
                        echo '<div class="d-flex justify-content-between align-items-center mb-2">';
                        echo '<h5 class="mb-0">'.$loan['loan_name'].'</h5>';
                        echo '<span class="badge badge-priority priority-'.$rec['priority'].'-badge">';
                        echo 'Priority '.$rec['priority'];
                        echo '</span>';
                        echo '</div>';
                        
                        echo '<div class="row">';
                        echo '<div class="col-md-6">';
                        echo '<p class="mb-1"><strong>EMI Amount:</strong> ₹'.number_format($loan['emi_amount'], 2).'</p>';
                        echo '<p class="mb-1"><strong>Pending EMIs:</strong> '.$loan['pending_emi'].'</p>';
                        echo '<p class="mb-1"><strong>Interest:</strong> ₹'.number_format($loan['interest'], 2).'</p>';
                        echo '</div>';
                        echo '<div class="col-md-6">';
                        echo '<p class="mb-1"><strong>Pending Amount:</strong> ₹'.number_format($loan['pending_amount'], 2).'</p>';
                        echo '<p class="mb-1"><strong>Paid Amount:</strong> ₹'.number_format($loan['paid_amount'], 2).'</p>';
                        echo '<p class="mb-1"><strong>Urgency Score:</strong> '.number_format($rec['urgency_score'], 1).'/100</p>';
                        echo '</div>';
                        echo '</div>';
                        
                        echo '<p class="mt-2 mb-0"><i class="fas fa-info-circle me-2"></i><strong>Recommendation:</strong> '.$rec['reason'].'</p>';
                        echo '</div>';
                    }
                    
                    echo '</div>';
                    
                    // Additional strategic advice
                    echo '<div class="ai-recommendation">';
                    echo '<h5><i class="fas fa-chess me-2"></i> Strategic Advice</h5>';
                    echo '<ul class="mb-0">';
                    echo '<li>Focus on <strong>high priority loans</strong> first to reduce interest burden</li>';
                    echo '<li>Consider <strong>prepaying loans</strong> with less than 3 EMIs remaining to close them quickly</li>';
                    echo '<li>For loans with <strong>high interest rates</strong>, explore refinancing options</li>';
                    echo '<li>After clearing high priority loans, allocate those EMI amounts to the next priority loans</li>';
                    echo '</ul>';
                    echo '</div>';
                } else {
                    echo '<div class="alert alert-info">No loans found for analysis</div>';
                }
                ?>
            </div>
        </div>
        
        <!-- Standard Reports -->
        <?php
        // Function to execute SQL query and display results with enhanced UI
        function executeQuery($conn, $sql, $title, $icon) {
            $result = $conn->query($sql);

            echo '<div class="report-section hover-effect mt-4">';
            echo '<div class="section-header">';
            echo '<i class="fas '.$icon.' me-2"></i> '.$title;
            echo '</div>';
            echo '<div class="p-3">';
            
            if ($result->num_rows > 0) {
                echo '<div class="table-responsive">';
                echo '<table class="table table-hover">';
                echo '<thead>';
                echo '<tr>';
                echo '<th>Loan Name</th>';
                echo '<th class="text-end">EMI Amount</th>';
                echo '<th class="text-end">Pending EMIs</th>';
                echo '<th class="text-end">Tenure</th>';
                echo '<th class="text-end">Pending Amount</th>';
                echo '<th class="text-end">Paid Amount</th>';
                echo '<th class="text-end">Interest</th>';
                echo '</tr>';
                echo '</thead>';
                echo '<tbody>';

                while($row = $result->fetch_assoc()) {
                    echo '<tr class="cursor-pointer" onclick="window.location=\'loan_details.php?id='.$row['loan_id'].'\'">';
                    echo '<td>'.htmlspecialchars($row['loan_name']).'</td>';
                    echo '<td class="text-end">₹'.number_format($row['emi_amount'], 2).'</td>';
                    echo '<td class="text-end">'.$row['pending_emi'].'</td>';
                    echo '<td class="text-end">'.$row['emi_tenure'].'</td>';
                    echo '<td class="text-end">₹'.number_format($row['pending_amount'], 2).'</td>';
                    echo '<td class="text-end">₹'.number_format($row['paid_amount'], 2).'</td>';
                    echo '<td class="text-end">₹'.number_format($row['interest'], 2).'</td>';
                    echo '</tr>';
                }

                echo '</tbody>';
                echo '</table>';
                echo '</div>';
            } else {
                echo '<div class="alert alert-info">No results found</div>';
            }
            
            echo '</div>';
            echo '</div>';
        }

        // Execute and display all reports
        executeQuery($conn, "SELECT * FROM loans ORDER BY pending_emi DESC LIMIT 5", 
                     "Top 5 Loans with Highest Pending EMIs", "fa-exclamation-triangle");
        executeQuery($conn, "SELECT * FROM loans ORDER BY pending_emi ASC LIMIT 5", 
                     "Top 5 Loans with Lowest Pending EMIs", "fa-check-circle");
        executeQuery($conn, "SELECT * FROM loans ORDER BY emi_amount DESC LIMIT 5", 
                     "Top 5 Loans with Highest EMI Amount", "fa-arrow-up");
        executeQuery($conn, "SELECT * FROM loans ORDER BY emi_amount ASC LIMIT 5", 
                     "Top 5 Loans with Lowest EMI Amount", "fa-arrow-down");
        executeQuery($conn, "SELECT * FROM loans ORDER BY interest DESC LIMIT 5", 
                     "Top 5 Loans with Highest Interest", "fa-percentage");
        executeQuery($conn, "SELECT * FROM loans ORDER BY interest ASC LIMIT 5", 
                     "Top 5 Loans with Lowest Interest", "fa-percent");
        executeQuery($conn, "SELECT * FROM loans ORDER BY pending_amount ASC LIMIT 5", 
                     "Top 5 Loans with Lowest Pending Amount", "fa-coins");
        executeQuery($conn, "SELECT * FROM loans ORDER BY pending_amount DESC LIMIT 5", 
                     "Top 5 Loans with Highest Pending Amount", "fa-money-bill-wave");
        executeQuery($conn, "SELECT * FROM loans ORDER BY paid_amount DESC LIMIT 5", 
                     "Top 5 Loans with Highest Paid Amount", "fa-receipt");
        executeQuery($conn, "SELECT * FROM loans ORDER BY paid_amount ASC LIMIT 5", 
                     "Top 5 Loans with Lowest Paid Amount", "fa-file-invoice-dollar");
        ?>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Add hover effects and click handlers
        document.addEventListener('DOMContentLoaded', function() {
            // Make table rows clickable
            document.querySelectorAll('tr.cursor-pointer').forEach(row => {
                row.addEventListener('click', function() {
                    window.location = this.getAttribute('onclick').match(/'(.*?)'/)[1];
                });
            });
        });
    </script>
</body>
</html>
<?php
$conn->close();
?>