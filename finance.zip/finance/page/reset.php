<?php
session_start();
require '../db/dbconnection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reset_submit'])) {
    // Retrieve form data safely
    $email = trim($_POST['email']);
    $username = trim($_POST['username']);
    $mobile = trim($_POST['mobile']);
    $new_password = trim($_POST['new_password']);

    // Validate inputs
    if (empty($email) || empty($username) || empty($mobile) || empty($new_password)) {
        $_SESSION['error'] = "Please fill in all fields.";
    } else {
        // Prepare a secure query to check user details
        $query = "SELECT * FROM users WHERE email = ? AND username = ? AND mobile = ?";
        $stmt = mysqli_prepare($connection, $query);
        mysqli_stmt_bind_param($stmt, "sss", $email, $username, $mobile);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) > 0) {
            // Update the password for the matching user
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_query = "UPDATE users SET password_hash = ? WHERE email = ?";
            $update_stmt = mysqli_prepare($connection, $update_query);
            mysqli_stmt_bind_param($update_stmt, "ss", $hashed_password, $email);
            
            if (mysqli_stmt_execute($update_stmt)) {
                $_SESSION['success'] = "Password reset successful.";
            } else {
                $_SESSION['error'] = "Error updating password. Please try again.";
            }
        } else {
            $_SESSION['error'] = "Invalid information. Please check your details and try again.";
        }
    }

    // Redirect to the same page to show messages
    header("Location: reset_password.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-body">
                    <h5 class="card-title text-center">Reset Credentials
                        <br><i class="fa fa-vcard" style="font-size:48px;color:red"></i>
                    </h5>

                    <!-- Display session messages -->
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
                    <?php endif; ?>

                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
                    <?php endif; ?>

                    <form method="post" action="">
                        <div class="form-group mb-3">
                            <input type="email" class="form-control" name="email" placeholder="Enter Your E-Mail" required>
                        </div>
                        <div class="form-group mb-3">
                            <input type="text" class="form-control" name="username" placeholder="Enter Your Username" required>
                        </div>
                        <div class="form-group mb-3">
                            <input type="text" class="form-control" name="mobile" placeholder="Enter Your Mobile Number" required>
                        </div>
                        <div class="form-group mb-3">
                            <input type="password" class="form-control" name="new_password" placeholder="New Password" required minlength="6">
                        </div>
                        <button type="submit" name="reset_submit" class="btn btn-primary btn-block">Reset Password</button>
                    </form>

                    <br>
                    <a href="login.php"><button class="btn btn-success">Sign In</button></a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
