<?php require_once 'includes/header.php'; ?>
<?php
// Database connection
$servername = "localhost"; // Change if needed
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$creditorName = $creditorAmount = $purpose = $pendingAmount = $paidAmount = $lastUpdateDate = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $creditorName = $_POST["creditor_name"];
    $creditorAmount = $_POST["creditor_amount"];
    $purpose = $_POST["purpose"];
    $pendingAmount = $_POST["pending_amount"];
    $paidAmount = $_POST["paid_amount"];
    $lastUpdateDate = $_POST["last_update_date"];

    // Insert data into database
    $sql = "INSERT INTO credit (name, amount, purpose, pending_amount, paid_amount, last_update_date)
            VALUES ('$creditorName', '$creditorAmount', '$purpose', '$pendingAmount', '$paidAmount', '$lastUpdateDate')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>New record created successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error: " . $sql . "<br>" . $conn->error . "</div></div>";
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Credit Details</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .form-container {
            max-width: 600px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h2 { text-align: center; color: #007bff; }
    </style>
</head>
<body>
    <div class="container mt-5">
        <ol class="breadcrumb">
            <li><a href="dashboard.php">Home</a></li>		  
            <li class="active"> Add Credit</li>
        </ol>

        <div class="form-container">
            <h2>Add Credit Details</h2>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="needs-validation" novalidate>
                <div class="form-group">
                    <label for="creditor_name">Creditor Name:</label>
                    <input type="text" class="form-control" id="creditor_name" name="creditor_name" required>
                    <div class="invalid-feedback">Please enter the creditor name.</div>
                </div>
                <div class="form-group">
                    <label for="creditor_amount">Creditor Amount:</label>
                    <input type="number" class="form-control" id="creditor_amount" name="creditor_amount" step="0.01" required oninput="calculatePendingAmount()">
                    <div class="invalid-feedback">Please enter the creditor amount.</div>
                </div>
                <div class="form-group">
                    <label for="purpose">Purpose:</label>
                    <textarea class="form-control" id="purpose" name="purpose" required></textarea>
                    <div class="invalid-feedback">Please enter the purpose.</div>
                </div>
                <div class="form-group">
                    <label for="paid_amount">Paid Amount:</label>
                    <input type="number" class="form-control" id="paid_amount" name="paid_amount" step="0.01" required oninput="calculatePendingAmount()">
                    <div class="invalid-feedback">Please enter the paid amount.</div>
                </div>
                <div class="form-group">
                    <label for="pending_amount">Pending Amount:</label>
                    <input type="number" class="form-control" id="pending_amount" name="pending_amount" step="0.01" readonly>
                </div>
                <div class="form-group">
                    <label for="last_update_date">Last Update Date:</label>
                    <input type="date" class="form-control" id="last_update_date" name="last_update_date" required>
                    <div class="invalid-feedback">Please enter the last update date.</div>
                </div>
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="glyphicon glyphicon-plus-sign"></i> Submit
                </button>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- JavaScript for dynamic pending amount calculation -->
    <script>
        function calculatePendingAmount() {
            var creditorAmount = parseFloat(document.getElementById('creditor_amount').value) || 0;
            var paidAmount = parseFloat(document.getElementById('paid_amount').value) || 0;
            var pendingAmount = creditorAmount - paidAmount;
            document.getElementById('pending_amount').value = pendingAmount.toFixed(2);
        }
    </script>
</body>
</html>
