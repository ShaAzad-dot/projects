
<?php
require_once 'includes/header.php'; 

// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    echo "Error: No debt ID provided.";
    exit();
}

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch debt details based on ID
$id = $_GET['id'];
$sql = "SELECT * FROM debt_details WHERE id = $id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Error: Debt not found.";
    exit();
}

// Initialize variables with current data
$creditorName = $row['creditor_name'];
$creditorAmount = $row['creditor_amount'];
$paidAmount = $row['paid_amount'];
$pendingAmount = $row['pending_amount'];
$payoffDate = $row['payoff_date'];

// Update debt details if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $creditorName = $_POST["creditor_name"];
    $creditorAmount = $_POST["creditor_amount"];
    $paidAmount = $_POST["paid_amount"];
    $pendingAmount = $_POST["pending_amount"];
    $payoffDate = $_POST["payoff_date"];

    // Update SQL query
    $updateSql = "UPDATE debt_details SET creditor_name='$creditorName', creditor_amount='$creditorAmount', paid_amount='$paidAmount', pending_amount='$pendingAmount', payoff_date='$payoffDate' WHERE id=$id";

    if ($conn->query($updateSql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>Record updated successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error updating record: " . $conn->error . "</div></div>";
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Debt Details</title>
    <!-- Bootstrap CSS -->
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Debt Details</h2>
        <form id="debtForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $id; ?>" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="creditor_name">Creditor Name:</label>
                <input type="text" class="form-control" id="creditor_name" name="creditor_name" value="<?php echo $creditorName; ?>" required>
                <div class="invalid-feedback">Please enter the creditor name.</div>
            </div>
            <div class="form-group">
                <label for="creditor_amount">Creditor Amount:</label>
                <input type="text" class="form-control" id="creditor_amount" name="creditor_amount" value="<?php echo $creditorAmount; ?>" required>
                <div class="invalid-feedback">Please enter the creditor amount.</div>
            </div>
            <div class="form-group">
                <label for="paid_amount">Paid Amount:</label>
                <input type="text" class="form-control" id="paid_amount" name="paid_amount" value="<?php echo $paidAmount; ?>" required>
                <div class="invalid-feedback">Please enter the paid amount.</div>
            </div>
            <div class="form-group">
                <label for="pending_amount">Pending Amount:</label>
                <input type="text" class="form-control" id="pending_amount" name="pending_amount" value="<?php echo $pendingAmount; ?>" required>
                <div class="invalid-feedback">Please enter the pending amount.</div>
            </div>
            <div class="form-group">
                <label for="payoff_date">Payoff Date:</label>
                <input type="date" class="form-control" id="payoff_date" name="payoff_date" value="<?php echo $payoffDate; ?>" required>
                <div class="invalid-feedback">Please enter the payoff date.</div>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="debt_details.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Form validation script -->
    <script>
        // JavaScript for form validation
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
		
		
		
		
		
		
		
		
		
		 // Function to calculate pending amount
        function calculatePendingAmount() {
            var creditorAmount = parseFloat(document.getElementById('creditor_amount').value);
            var paidAmount = parseFloat(document.getElementById('paid_amount').value);
            var pendingAmount = creditorAmount - paidAmount;

            // Display the result in the pending amount input field
            document.getElementById('pending_amount').value = pendingAmount.toFixed(2);
        }

        // Event listener to trigger the calculation when paid amount input value changes
        document.getElementById('paid_amount').addEventListener('input', calculatePendingAmount);
   
		
		
		
		
		
		
		
		
		
		
		
		
    </script>
</body>
</html>
