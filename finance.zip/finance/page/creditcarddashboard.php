To display the following details from your debt table:

1. Total Number of Debts
2. Total Debt Amount
3. Total Amount Paid
4. Total Pending Amount

You can fetch this information using SQL queries and then display them on your webpage. Here's how you can do it:

```php
<?php
require_once 'includes/header.php';

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Debt Details</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Debt Details</h2>
        <div class="row">
            <div class="col-md-6">
                <div class="card text-center">
                    <div class="card-header">
                        Total Number of Debts
                    </div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $totalDebts; ?></h5>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card text-center">
                    <div class="card-header">
                        Total Debt Amount
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">INR <?php echo number_format($totalDebtAmount, 2); ?></h5>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card text-center">
                    <div class="card-header">
                        Total Amount Paid
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">INR <?php echo number_format($totalAmountPaid, 2); ?></h5>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card text-center">
                    <div class="card-header">
                        Total Pending Amount
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">INR <?php echo number_format($totalPendingAmount, 2); ?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
```

This code fetches the required information from the debt_details table and displays it in a card layout using Bootstrap. Adjust the styling as needed to fit your design preferences.