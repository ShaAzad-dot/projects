<?php
require '../db/dbconnection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login_submit'])) {
    $login_email = isset($_POST['login_email']) ? $_POST['login_email'] : '';
    $login_password = isset($_POST['login_password']) ? $_POST['login_password'] : '';

    // Retrieve user data from the database based on the provided email
    $query = "SELECT * FROM users WHERE email = ?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "s", $login_email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        // Verify the password
        if (password_verify($login_password, $user['password_hash'])) {
            // Set session variables
            session_start();
            $_SESSION['username'] = $user['username'];
            // Redirect to dashboard
            header("Location: dashboard.php");
            exit();
        } else {
            $error_message = "Incorrect password. Please try again.";
        }
    } else {
        $error_message = "User with this email does not exist.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea, #764ba2);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-container {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            width: 350px;
            text-align: center;
            animation: fadeIn 1s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            border: none;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #5563c1, #5e3f85);
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2><i class="fa fa-user-circle" style="font-size:48px; color:#667eea;"></i></h2>
        <h3>Login</h3>
        <?php if (isset($error_message)) { echo "<p style='color:red;'>$error_message</p>"; } ?>
        <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
            <div class="mb-3">
                <input type="email" class="form-control" name="login_email" placeholder="Email" required>
            </div>
            <div class="mb-3">
                <input type="password" class="form-control" name="login_password" placeholder="Password" required>
            </div>
            <button type="submit" name="login_submit" class="btn btn-primary w-100">Login</button>
        </form>
        <p class="mt-3">Forgot Credentials? <a href="reset.php" class="btn btn-success btn-sm">Reset</a></p>
    </div>
</body>
</html>
