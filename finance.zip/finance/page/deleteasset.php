
<?php
require_once 'includes/header.php';

// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    echo "Error: No asset ID provided.";
    exit();
}

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch asset details based on ID
$id = $_GET['id'];

// Execute DELETE query
$sql = "DELETE FROM asset WHERE Asset_ID = $id";

if ($conn->query($sql) === TRUE) {
    echo "<div class='container mt-3'><div class='alert alert-success'>Asset deleted successfully</div></div>";
} else {
    echo "<div class='container mt-3'><div class='alert alert-danger'>Error deleting asset: " . $conn->error . "</div></div>";
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete Asset</title>
    <!-- Bootstrap CSS -->
</head>
<body>
<div class="container mt-5">
    <h2>Delete Asset</h2>
    <p>Asset has been successfully deleted.</p>
    <a href="manageasset.php" class="btn btn-primary">Back to Asset Listing</a>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
