<?php require_once 'includes/header.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Asset Details</title>

    <style>
        body {
            background-color: #f0f2f5;
        }
        .container {
            margin-top: 50px;
        }
        .card {
            border-radius: 10px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.1);
            background: #ffffff;
            padding: 30px;
        }
        .form-control {
            border-radius: 5px;
            border: 1px solid #ced4da;
        }
        .btn-custom {
            background: linear-gradient(45deg, #28a745, #218838);
            color: white;
            border-radius: 30px;
            font-weight: bold;
            padding: 10px;
        }
        .btn-custom:hover {
            background: linear-gradient(45deg, #218838, #1e7e34);
        }
        .form-group label {
            font-weight: bold;
        }
        .header-title {
            font-size: 24px;
            font-weight: bold;
            color: #343a40;
            text-align: center;
            margin-bottom: 20px;
        }
        .icon {
            font-size: 18px;
            margin-right: 5px;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <h3 class="header-title"><i class="fas fa-box"></i> Add Asset Details</h3>
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="needs-validation" novalidate>
                    <div class="form-group">
                        <label for="asset_name"><i class="fas fa-tag icon"></i> Asset Name:</label>
                        <input type="text" class="form-control" id="asset_name" name="asset_name" required>
                        <div class="invalid-feedback">Please enter the asset name.</div>
                    </div>
                    <div class="form-group">
                        <label for="purchase_value"><i class="fas fa-dollar-sign icon"></i> Purchase Value:</label>
                        <input type="number" class="form-control" id="purchase_value" name="purchase_value" required>
                        <div class="invalid-feedback">Please enter the purchase value.</div>
                    </div>
                    <div class="form-group">
                        <label for="asset_current_value"><i class="fas fa-chart-line icon"></i> Asset Current Value:</label>
                        <input type="number" class="form-control" id="asset_current_value" name="asset_current_value" required>
                        <div class="invalid-feedback">Please enter the current value of the asset.</div>
                    </div>
                    <div class="form-group">
                        <label for="last_update_date"><i class="fas fa-calendar-alt icon"></i> Last Update Date:</label>
                        <input type="date" class="form-control" id="last_update_date" name="last_update_date" required>
                        <div class="invalid-feedback">Please enter the last update date.</div>
                    </div>
                    <button type="submit" class="btn btn-custom btn-block"><i class="fas fa-plus-circle"></i> Submit</button>
                </form>

                <?php
                // Database connection
                $servername = "localhost"; 
                $username = "root";
                $password = "";
                $database = "finance";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $database);

                // Check connection
                if ($conn->connect_error) {
                    die("<div class='alert alert-danger mt-3'>Connection failed: " . $conn->connect_error . "</div>");
                }

                // Handle form submission
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $assetName = $_POST["asset_name"];
                    $purchaseValue = $_POST["purchase_value"];
                    $assetCurrentValue = $_POST["asset_current_value"];
                    $lastUpdateDate = $_POST["last_update_date"];

                    // SQL to insert data
                    $sql = "INSERT INTO asset (Asset_Name, Purchase_Value, Asset_Current_Value, Last_Update_Date)
                            VALUES ('$assetName', '$purchaseValue', '$assetCurrentValue', '$lastUpdateDate')";

                    if ($conn->query($sql) === TRUE) {
                        echo "<div class='alert alert-success mt-3'><i class='fas fa-check-circle'></i> New asset added successfully.</div>";
                    } else {
                        echo "<div class='alert alert-danger mt-3'><i class='fas fa-exclamation-circle'></i> Error: " . $conn->error . "</div>";
                    }
                }

                // Close connection
                $conn->close();
                ?>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap & FontAwesome -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>

<script>
    // JavaScript for form validation
    (function() {
        'use strict';
        window.addEventListener('load', function() {
            var forms = document.getElementsByClassName('needs-validation');
            Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();
</script>

</body>
</html>
