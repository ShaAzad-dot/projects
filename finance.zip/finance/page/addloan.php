
<?php require_once 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Loan Details</title>
    <!-- Bootstrap CSS -->
 
	
</head>
<body>
    <div class="container mt-5">
        <ol class="breadcrumb">
            <li><a href="dashboard.php">Home</a></li>		  
            <li class="active"> Add Loan</li>
        </ol>
        <h2>Add Loan Details</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="loan_name">Loan Name:</label>
                <input type="text" class="form-control" id="loan_name" name="loan_name" required>
                <div class="invalid-feedback">Please enter the loan name.</div>
            </div>
            <div class="form-group">
                <label for="loan_type">Loan Type:</label>
                <input type="text" class="form-control" id="loan_type" name="loan_type" required>
                <div class="invalid-feedback">Please enter the loan type.</div>
            </div>
			
			
			 <div class="form-group">
                <label for="loan_owner">Loan Owner:</label>
                <input type="text" class="form-control" id="loan_owner" name="loan_owner" required>
                <div class="invalid-feedback">Please enter the loan owner.</div>
            </div>
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
            <div class="form-group">
                <label for="principle_amount">Principal Amount:</label>
                <input type="number" class="form-control" id="principle_amount" name="principle_amount" required>
                <div class="invalid-feedback">Please enter the principal amount.</div>
            </div>
            <div class="form-group">
                <label for="emi_amount">EMI Amount:</label>
                <input type="number" class="form-control" id="emi_amount" name="emi_amount" required>
                <div class="invalid-feedback">Please enter the EMI amount.</div>
            </div>
            <div class="form-group">
                <label for="emi_tenure">EMI Tenure (months):</label>
                <input type="number" class="form-control" id="emi_tenure" name="emi_tenure" required>
                <div class="invalid-feedback">Please enter the EMI tenure in months.</div>
            </div>
            <div class="form-group">
                <label for="total_amount">Total Amount:</label>
                <input type="number" class="form-control" id="total_amount" name="total_amount" readonly>
            </div>
            <div class="form-group">
                <label for="emi_date">EMI Date:</label>
                <input type="date" class="form-control" id="emi_date" name="emi_date" required>
                <div class="invalid-feedback">Please enter the EMI date.</div>
            </div>
            <div class="form-group">
                <label for="paid_emi">Paid EMI:</label>
                <input type="number" class="form-control" id="paid_emi" name="paid_emi" required  onchange=" pendingAmount();" >
                <div class="invalid-feedback">Please enter the paid EMI.</div>
            </div>
            <div class="form-group">
                <label for="pending_emi">Pending EMI:</label>
                <input type="number" class="form-control" id="pending_emi" name="pending_emi" readonly>
                <div class="invalid-feedback">Please enter the pending EMI.</div>
            </div>
            <div class="form-group">
                <label for="paid_amount">Paid Amount:</label>
                <input type="number" class="form-control" id="paid_amount" name="paid_amount" readonly>
                <div class="invalid-feedback">Please enter the paid amount.</div>
            </div>
            <div class="form-group">
                <label for="pending_amount">Pending Amount:</label>
                <input type="number" class="form-control" id="pending_amount" name="pending_amount" readonly>
                <div class="invalid-feedback">Please enter the pending amount.</div>
            </div>
            <div class="form-group">
                <label for="interest">Interest:</label>
                <input type="number" class="form-control" id="interest" name="interest" readonly>
                <div class="invalid-feedback">Please enter the interest.</div>
				<button type="button" class="btn btn-danger" onclick="interestAmount();">Calculate Interest</button>
				
            </div>
            <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-plus-sign"></i>   Submit</button>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Form validation script -->
    <script>
        // JavaScript for form validation
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();

        // Function to calculate total amount
        function calculateTotalAmount() {
           

 var emiAmount = parseFloat(document.getElementById('emi_amount').value);
            var emiTenure = parseFloat(document.getElementById('emi_tenure').value);
            var totalAmount = (emiAmount * emiTenure).toFixed(2);

            // Display the result in the total amount input field
            document.getElementById('total_amount').value = totalAmount;
        }

        // Event listeners to trigger the calculation when input values change
        document.getElementById('emi_amount').addEventListener('input', calculateTotalAmount);
        document.getElementById('emi_tenure').addEventListener('input', calculateTotalAmount);

        // Call the function initially to populate total amount
        calculateTotalAmount();
		
		
		
		
		
		
		
		
		
		
		
		// Function to calculate pending EMI
function calculatePendingEMI() {
    var paidEMI = parseFloat(document.getElementById('paid_emi').value);
    var emiTenure = parseFloat(document.getElementById('emi_tenure').value);
    var pendingEMI = emiTenure - paidEMI;

    // Display the result in the pending EMI input field
    document.getElementById('pending_emi').value = pendingEMI.toFixed(2);
}

// Event listeners to trigger the calculation when input values change
document.getElementById('paid_emi').addEventListener('input', calculatePendingEMI);
document.getElementById('emi_tenure').addEventListener('input', calculatePendingEMI);

// Call the function initially to populate pending EMI
calculatePendingEMI();

		
		
		
		


		
		// Function to calculate paid amount
function calculatePaidAmount() {
    var paidEMI = parseFloat(document.getElementById('paid_emi').value);
    var emiTenure = parseFloat(document.getElementById('emi_amount').value);
    var paidAmount = (paidEMI * emiTenure).toFixed(2);

    // Display the result in the paid amount input field
    document.getElementById('paid_amount').value = paidAmount;
}

// Event listeners to trigger the calculation when input values change
document.getElementById('paid_emi').addEventListener('input', calculatePaidAmount);
document.getElementById('emi_tenure').addEventListener('input', calculatePaidAmount);

// Call the function initially to populate paid amount
calculatePaidAmount();

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
// Function to calculate pending amount
function calculatePendingAmount() {
    var pendingEMI = parseFloat(document.getElementById('pending_emi').value);
    var emiAmount = parseFloat(document.getElementById('emi_amount').value);
    var pendingAmount = (pendingEMI * emiAmount).toFixed(2);

    // Display the result in the pending amount input field
    document.getElementById('pending_amount').value = pendingAmount;
}

// Event listeners to trigger the calculation when input values change
document.getElementById('pending_emi').addEventListener('input', calculatePendingAmount);
document.getElementById('emi_amount').addEventListener('input', calculatePendingAmount);

// Call the function initially to populate pending amount
calculatePendingAmount();
	
		
		
		
		
		
		
		
		
		
		
		
		function pendingAmount()
		{

			var pendingEmi = document.getElementById('pending_emi').value;
			
			var emiAmount = document.getElementById('emi_amount').value;
			var result = pendingEmi*emiAmount;
			
			document.getElementById('pending_amount').value = result;
			
			pendingAmount();

		}
		
		
		
		
		
			
		function interestAmount()
		{

			var TMA = document.getElementById('total_amount').value;
			
			var PMA = document.getElementById('principle_amount').value;
			var result = TMA-PMA;
			
			document.getElementById('interest').value = result;
			
			
		

		}
		
		
		
		
		
		
		
		

		
		
		
		
		
		
		
		// Function to calculate pending amount
function calculatePendingAmount() {
    var pendingEMI = parseFloat(document.getElementById('pending_emi').value);
    var emiTenure = parseFloat(document.getElementById('emi_amount').value);
    var pendingAmount = (pendingEMI * emiTenure).toFixed(2);

    // Display the result in the pending amount input field
    document.getElementById('pending_amount').value = pendingAmount;
}

// Event listeners to trigger the calculation when input values change
document.getElementById('pending_emi').addEventListener('input', calculatePendingAmount);
document.getElementById('emi_tenure').addEventListener('input', calculatePendingAmount);

// Call the function initially to populate pending amount
calculatePendingAmount();

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
    </script>
</body>
</html>

<?php
// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables to store form data
$loanName = $loanType = $principleAmount = $emiAmount = $emiTenure = $totalAmount = $emiDate = $paidEmi = $pendingEmi = $paidAmount = $pendingAmount = $interest = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $loanName = $_POST["loan_name"];
    $loanType = $_POST["loan_type"];
    $principleAmount = $_POST["principle_amount"];
    $emiAmount = $_POST["emi_amount"];
    $emiTenure = $_POST["emi_tenure"];
    $totalAmount = $_POST["total_amount"];
    $emiDate = $_POST["emi_date"];
    $paidEmi = $_POST["paid_emi"];
    $pendingEmi = $_POST["pending_emi"];
    $paidAmount = $_POST["paid_amount"];
    $pendingAmount = $_POST["pending_amount"];
    $interest = $_POST["interest"];
    $loanOwner = $_POST["loan_owner"];

   
	
	
    // SQL to insert data into table
    $sql = "INSERT INTO loans (loan_name, loan_type, principle_amount, emi_amount, emi_tenure, total_amount, emi_date, paid_emi, pending_emi, paid_amount, pending_amount, interest,loan_owner)
            VALUES ('$loanName', '$loanType', '$principleAmount', '$emiAmount', '$emiTenure', '$totalAmount', '$emiDate', '$paidEmi', '$pendingEmi', '$paidAmount', '$pendingAmount', '$interest','$loanOwner')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>New record created successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error: " . $sql . "<br>" . $conn->error . "</div></div>";
    }
}

// Close connection
$conn->close();
?>
