
<?php require_once 'includes/header.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Expense Details</title>
    <!-- Bootstrap CSS -->
</head>
<body>
<div class="container">
    <ol class="breadcrumb">
        <li><a href="dashboard.php">Home</a></li>
        <li class="active">Expense Details</li>
    </ol>
    <div class="container mt-5">
        <h2>Expense Details</h2>
        <div class="panel panel-default">
            <div class="panel-heading">
                <div class="page-heading"><i class="glyphicon glyphicon-edit"></i> Manage Expenses</div>
            </div>
            <!-- /panel-heading -->
            <div class="panel-body">
                <div class="remove-messages"></div>
				  <div class="div-action pull pull-right" style="padding-bottom:20px;">
                    <a href="addexpense.php" style="text-decoration:none;"> <button class="btn btn-danger button1"> <i class="glyphicon glyphicon-plus-sign"></i> Add Expense </button></a>
                </div>
                <table class="table">
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Amount</th>
                        <th>Date</th>
                        <th>Bank</th>
                        <th>Bill</th>
                        <th>Others</th>
                        <th>Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    // Database connection
                    $servername = "localhost"; // Change this if your database is hosted elsewhere
                    $username = "root";
                    $password = "";
                    $database = "finance";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $database);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Fetch data from database
                    $sql = "SELECT * FROM Expense";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row['Name'] . "</td>";
                            echo "<td>" . $row['Category'] . "</td>";
                            echo "<td>INR " . $row['Amount'] . "</td>";
                            echo "<td>" . $row['Date'] . "</td>";
                            echo "<td>" . $row['Bank'] . "</td>";
                            echo "<td>" . $row['Bill'] . "</td>";
                            echo "<td>" . $row['Others'] . "</td>";
                            echo "<td>
                                <a href='editexpense.php?id=" . $row['ExpenseID'] . "' class='btn btn-primary btn-sm'>Edit</a>
                                <a href='deleteexpense.php?id=" . $row['ExpenseID'] . "' class='btn btn-danger btn-sm'>Delete</a>
                              </td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8'>No expense details found</td></tr>";
                    }

                    // Close connection
                    $conn->close();
                    ?>
                    </tbody>
                </table>
            </div>
            <!-- /panel-body -->
        </div>
        <!-- /panel -->
    </div>
    <!-- /container mt-5 -->
</div>
<!-- /container -->

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
