<?php 
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if header exists before including
$header_path = 'includes/header.php';
if (!file_exists($header_path)) {
    die("Error: Header file not found at $header_path");
}

require_once $header_path;

// Database connection with error handling
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "finance";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("<div class='alert alert-danger'>Connection failed: " . $conn->connect_error . "</div>");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Alerts Dashboard</title>
    <!-- Bootstrap CSS -->

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <style>
        :root {
            --urgent-red: #e63946;
            --warning-orange: #f77f00;
            --safe-green: #2a9d8f;
            --primary-blue: #1d3557;
            --light-bg: #f1faee;
        }
        
        body {
            background-color: var(--light-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .alert-card {
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
            margin-bottom: 25px;
            overflow: hidden;
            border: none;
        }
        
        .alert-card:hover {
            transform: translateY(-5px);
        }
        
        .alert-header {
            padding: 15px 20px;
            color: white;
            font-weight: 600;
        }
        
        .loans-header {
            background-color: var(--urgent-red);
        }
        
        .cards-header {
            background-color: var(--primary-blue);
        }
        
        .alert-body {
            padding: 20px;
            background-color: white;
        }
        
        .table-responsive {
            border-radius: 8px;
            overflow: hidden;
        }
        
        .table th {
            background-color: var(--primary-blue);
            color: white;
            font-weight: 600;
        }
        
        .urgent-row {
            background-color: rgba(230, 57, 70, 0.1);
            font-weight: 500;
        }
        
        .urgent-row:hover {
            background-color: rgba(230, 57, 70, 0.2);
        }
        
        .high-utilization {
            color: var(--urgent-red);
            font-weight: 600;
        }
        
        .medium-utilization {
            color: var(--warning-orange);
            font-weight: 600;
        }
        
        .low-utilization {
            color: var(--safe-green);
            font-weight: 600;
        }
        
        .pulse-animation {
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(230, 57, 70, 0.4); }
            70% { box-shadow: 0 0 0 10px rgba(230, 57, 70, 0); }
            100% { box-shadow: 0 0 0 0 rgba(230, 57, 70, 0); }
        }
        
        .progress {
            height: 8px;
            border-radius: 4px;
        }
        
        .progress-bar {
            background-color: var(--primary-blue);
        }
        
        .no-data {
            text-align: center;
            padding: 30px;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <!-- Loans Due Within One Week -->
        <div class="alert-card animate__animated animate__fadeInDown">
            <div class="alert-header loans-header">
                <div class="d-flex justify-content-between align-items-center">
                    <h4 class="mb-0"><i class="fas fa-exclamation-triangle me-2"></i> Loans Due Within One Week</h4>
                    <span class="badge bg-white text-danger"><?php 
                        // Count of loans due
                        $currentDate = date('Y-m-d');
                        $oneWeekLater = date('Y-m-d', strtotime('+1 week'));
                        $countSql = "SELECT COUNT(*) as count FROM loans WHERE emi_date BETWEEN '$currentDate' AND '$oneWeekLater'";
                        $countResult = $conn->query($countSql);
                        echo $countResult->fetch_assoc()['count'];
                    ?></span>
                </div>
            </div>
            <div class="alert-body">
                <?php
                $sql = "SELECT loan_name, emi_amount, emi_date FROM loans WHERE emi_date BETWEEN '$currentDate' AND '$oneWeekLater' ORDER BY emi_date ASC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    echo '<div class="table-responsive">';
                    echo '<table class="table table-hover">';
                    echo '<thead>';
                    echo '<tr>';
                    echo '<th><i class="fas fa-file-invoice-dollar me-2"></i>Loan Name</th>';
                    echo '<th class="text-end"><i class="fas fa-rupee-sign me-2"></i>EMI Amount</th>';
                    echo '<th class="text-end"><i class="far fa-calendar-alt me-2"></i>Due Date</th>';
                    echo '</tr>';
                    echo '</thead>';
                    echo '<tbody>';
                    
                    while ($row = $result->fetch_assoc()) {
                        $daysLeft = floor((strtotime($row['emi_date']) - strtotime($currentDate)) / (60 * 60 * 24));
                        $daysClass = $daysLeft <= 3 ? 'pulse-animation' : '';
                        
                        echo '<tr class="urgent-row ' . $daysClass . '">';
                        echo '<td>' . htmlspecialchars($row["loan_name"]) . '</td>';
                        echo '<td class="text-end">₹' . number_format($row["emi_amount"], 2) . '</td>';
                        echo '<td class="text-end">' . date('M j, Y', strtotime($row["emi_date"])) . ' <small>(' . $daysLeft . ' days)</small></td>';
                        echo '</tr>';
                    }
                    echo '</tbody>';
                    echo '</table>';
                    echo '</div>';
                } else {
                    echo '<div class="no-data">';
                    echo '<i class="far fa-check-circle fa-3x mb-3" style="color: var(--safe-green);"></i>';
                    echo '<h5>No loans with EMIs due within one week</h5>';
                    echo '<p class="text-muted">All payments are up to date</p>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>

        <!-- Credit Cards Utilization -->
        <div class="alert-card animate__animated animate__fadeInUp">
            <div class="alert-header cards-header">
                <div class="d-flex justify-content-between align-items-center">
                    <h4 class="mb-0"><i class="fas fa-credit-card me-2"></i> High Utilization Credit Cards</h4>
                    <span class="badge bg-white text-primary"><?php 
                        // Count of high utilization cards
                        $countSql = "SELECT COUNT(*) as count FROM credit_cards WHERE (utilized_limit / total_limit) > 0.8";
                        $countResult = $conn->query($countSql);
                        echo $countResult->fetch_assoc()['count'];
                    ?></span>
                </div>
            </div>
            <div class="alert-body">
                <?php
                $query = "SELECT * FROM credit_cards";
                $result = $conn->query($query);
                $credit_cards = [];

                if ($result) {
                    while ($row = $result->fetch_assoc()) {
                        $credit_cards[] = $row;
                    }
                } else {
                    echo "<div class='alert alert-danger'>Error fetching credit cards: " . $conn->error . "</div>";
                }

                if (!empty($credit_cards)) {
                    $highUtilizationCards = array_filter($credit_cards, function($card) {
                        return ($card['utilized_limit'] / $card['total_limit']) > 0.8;
                    });

                    if (!empty($highUtilizationCards)) {
                        echo '<div class="table-responsive">';
                        echo '<table class="table table-hover">';
                        echo '<thead>';
                        echo '<tr>';
                        echo '<th>Card Name</th>';
                        echo '<th>Total Limit</th>';
                        echo '<th>Available Limit</th>';
                        echo '<th>Utilized Limit</th>';
                        echo '<th>Utilization %</th>';
                        echo '</tr>';
                        echo '</thead>';
                        echo '<tbody>';
                        
                        foreach ($highUtilizationCards as $card) {
                            $utilization_percentage = ($card['utilized_limit'] / $card['total_limit']) * 100;
                            $utilization_class = '';
                            
                            if ($utilization_percentage > 90) {
                                $utilization_class = 'high-utilization';
                            } elseif ($utilization_percentage > 80) {
                                $utilization_class = 'medium-utilization';
                            }
                            
                            echo '<tr>';
                            echo '<td>' . htmlspecialchars($card["card_name"]) . '</td>';
                            echo '<td>₹' . number_format($card["total_limit"], 2) . '</td>';
                            echo '<td>₹' . number_format($card["available_limit"], 2) . '</td>';
                            echo '<td>₹' . number_format($card["utilized_limit"], 2) . '</td>';
                            echo '<td class="' . $utilization_class . '">';
                            echo '<div class="d-flex align-items-center">';
                            echo number_format($utilization_percentage, 1) . '%';
                            echo '<div class="progress ms-2" style="width: 100px; height: 8px;">';
                            echo '<div class="progress-bar" role="progressbar" style="width: ' . $utilization_percentage . '%" ';
                            echo 'aria-valuenow="' . $utilization_percentage . '" aria-valuemin="0" aria-valuemax="100"></div>';
                            echo '</div>';
                            echo '</div>';
                            echo '</td>';
                            echo '</tr>';
                        }
                        echo '</tbody>';
                        echo '</table>';
                        echo '</div>';
                    } else {
                        echo '<div class="no-data">';
                        echo '<i class="far fa-check-circle fa-3x mb-3" style="color: var(--safe-green);"></i>';
                        echo '<h5>No high utilization credit cards</h5>';
                        echo '<p class="text-muted">All cards are below 80% utilization</p>';
                        echo '</div>';
                    }
                } else {
                    echo '<div class="no-data">';
                    echo '<i class="fas fa-exclamation-circle fa-3x mb-3" style="color: var(--warning-orange);"></i>';
                    echo '<h5>No credit card data available</h5>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Add animation to elements when they come into view
        document.addEventListener('DOMContentLoaded', function() {
            const alertCards = document.querySelectorAll('.alert-card');
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('animate__fadeInUp');
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.1 });
            
            alertCards.forEach(card => {
                observer.observe(card);
            });
        });
    </script>
</body>
</html>
<?php
$conn->close();
?>