To list out all the paid and unpaid bills, you can execute two separate SQL queries to fetch the data from your `loans` table based on the status. Here's how you can do it:

```php
<?php require_once 'includes/header.php'?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Bills</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h2>Manage Bills</h2>

<h3>Paid Bills</h3>
<table>
    <tr>
        <th>Loan Name</th>
        <th>EMI Amount</th>
        <th>EMI Date</th>
    </tr>

    <?php
    // Connect to your database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "finance";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL query to retrieve paid bills
    $sql_paid = "SELECT loan_name, emi_amount, emi_date FROM loans WHERE status = 'paid'";
    $result_paid = $conn->query($sql_paid);

    // Output data of each row
    if ($result_paid->num_rows > 0) {
        while ($row = $result_paid->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["loan_name"] . "</td>
                    <td>" . $row["emi_amount"] . "</td>
                    <td>" . $row["emi_date"] . "</td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='3'>No paid bills found</td></tr>";
    }
    ?>

</table>

<h3>Unpaid Bills</h3>
<table>
    <tr>
        <th>Loan Name</th>
        <th>EMI Amount</th>
        <th>EMI Date</th>
    </tr>

    <?php
    // SQL query to retrieve unpaid bills
    $sql_unpaid = "SELECT loan_name, emi_amount, emi_date FROM loans WHERE status = 'unpaid'";
    $result_unpaid = $conn->query($sql_unpaid);

    // Output data of each row
    if ($result_unpaid->num_rows > 0) {
        while ($row = $result_unpaid->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["loan_name"] . "</td>
                    <td>" . $row["emi_amount"] . "</td>
                    <td>" . $row["emi_date"] . "</td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='3'>No unpaid bills found</td></tr>";
    }

    $conn->close();
    ?>

</table>

</body>
</html>
```

In this code:

- Two separate SQL queries are executed to fetch paid and unpaid bills from the `loans` table based on the `status` column.
- For each set of bills (paid and unpaid), a separate HTML table is displayed to list out the details.
- If there are no paid or unpaid bills found, appropriate messages are displayed.

Make sure to replace `"localhost"`, `"root"`, `""`, and `"finance"` with your actual database credentials.