
<?php require_once 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Expense</title>
    <!-- Bootstrap CSS -->
  
</head>
<body>
    <div class="container mt-5">
		<ol class="breadcrumb">
		    <li><a href="dashboard.php">Home</a></li>		  
		    <li class="active"> Add Expense</li>
		</ol>
        <h2>Add Expense</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control" id="name" name="name" required>
                <div class="invalid-feedback">Please enter the name.</div>
            </div>
            <div class="form-group">
                <label for="category">Category:</label>
                <input type="text" class="form-control" id="category" name="category" required>
                <div class="invalid-feedback">Please enter the category.</div>
            </div>
            <div class="form-group">
                <label for="amount">Amount:</label>
                <input type="number" class="form-control" id="amount" name="amount" required>
                <div class="invalid-feedback">Please enter the amount.</div>
            </div>
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" class="form-control" id="date" name="date" required>
                <div class="invalid-feedback">Please enter the date.</div>
            </div>
			
            <div class="form-group">
                <label for="bank">Amount Debited From:</label>
                <select class="form-control" id="bank" name="bank" required>
                    <option value="" selected disabled>Select Bank</option>
                    <?php
                    // Fetching bank data from the database
                    $servername = "localhost"; // Change this if your database is hosted elsewhere
                    $username = "root";
                    $password = "";
                    $database = "finance";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $database);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Query to fetch bank names and available balances
                    $sql = "SELECT bank_name, available_balance FROM bank";

                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row['bank_name'] . "'>" . $row['bank_name'] . " (Available Balance: INR " . $row['available_balance'] . ")</option>";
                        }
                    } else {
                        echo "<option value='' disabled>No banks found</option>";
                    }

                    // Close connection
                    $conn->close();
                    ?>
                </select>
                <div class="invalid-feedback">Please select a bank.</div>
            </div>

            <div class="form-group">
                <label for="bill">Expense Paid For Which Bill:</label>
               <select class="form-control" id="bill" name="bill" onchange="updateAmount();">
                    <option value="" selected disabled>Select a Bill</option>
                    <?php
                    // Fetching loan data from the database
                    $servername = "localhost"; // Change this if your database is hosted elsewhere
                    $username = "root";
                    $password = "";
                    $database = "finance";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $database);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Query to fetch loan names and EMI amounts
                    $sql = "SELECT loan_name, emi_amount FROM loans";

                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row['loan_name'] . "'>" . $row['loan_name'] . " (EMI Amount: INR " . $row['emi_amount'] . ")</option>";
                        }
                    } else {
                        echo "<option value='' disabled>No bills found</option>";
                    }

                    // Close connection
                    $conn->close();
                    ?>
                </select>
                <div class="invalid-feedback">Please select a bill.</div>
            </div>

            <div class="form-group">
                <label for="others">Others:</label>
                <textarea class="form-control" id="others" name="others" rows="3"></textarea>
            </div>
            <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-plus-sign"></i>   Submit</button>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Form validation script -->
    <script>
        // JavaScript for form validation
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();

        // JavaScript for populating bill dropdown
        $(document).ready(function() {
            $('#bill').click(function() {
                $.ajax({
                    url: 'get_loans.php', // PHP script to fetch loan data
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        $('#bill').empty(); // Clear existing options
                        $('#bill').append('<option value="">Select a Loan</option>'); // Add default option
                        $.each(response, function(index, loan) {
                            $('#bill').append('<option value="' + loan.loan_name + '">' + loan.loan_name + ' - EMI Amount: INR ' + loan.emi_amount + '</option>');
                        });
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                        alert('Error fetching loan data. Please try again.');
                    }
                });
            });
        });
		
		
		
		
		
		
		
		
		
		   // JavaScript for updating available balance dynamically
        $(document).ready(function() {
            $('#bankt').change(function() {
                var selectedOption = $(this).find(':selected');
                var balance = selectedOption.data('balance');
                $('#available_balance').val(balance);
            });
        });
		

		
		
		
		
		
		
		
		
		
		
    </script>
</body>
</html>

<?php
// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables to store form data
$name = $category = $amount = $date = $bank = $bill = $others = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $category = $_POST["category"];
    $amount = $_POST["amount"];
    $date = $_POST["date"];
    $bank = $_POST["bank"];
    $bill = $_POST["bill"];
    $others = $_POST["others"];
	
	
	
	
	
	
	 // Update bank's available balance
    $sqlUpdateBalance = "UPDATE bank SET available_balance = available_balance - $amount WHERE bank_name = '$bank'";
    if ($conn->query($sqlUpdateBalance) === FALSE) {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error updating available balance: " . $conn->error . "</div></div>";
    }
	
	
	
	
	

    // SQL to insert data into table
    $sql = "INSERT INTO Expense (Name, Category, Amount, Date, Bank, Bill, Others)
            VALUES ('$name', '$category', '$amount', '$date', '$bank', '$bill', '$others')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>New record created successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error: " . $sql . "<br>" . $conn->error . "</div></div>";
    }
}

// Close connection
$conn->close();
?>