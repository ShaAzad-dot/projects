<?php require_once 'includes/header.php'; ?>

<?php require_once 'includes/header.php';



// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch total number of credit cards
// Fetch total available card limit (sum of available limits)
$sql = "SELECT SUM(available_limit) AS total_available_limit FROM credit_cards";
$result = $conn->query($sql);

$totalAvailableLimit = 0; // Default value if no cards found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalAvailableLimit = $row['total_available_limit'];
}


$sql = "SELECT COUNT(*) AS total_cards FROM credit_cards";
$result = $conn->query($sql);

$totalCards = 0; // Default value if no cards found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalCards = $row['total_cards'];
}


// Fetch total utilized card limit (sum of utilized limits)
$sql = "SELECT SUM(total_limit - available_limit) AS total_utilized_limit FROM credit_cards";
$result = $conn->query($sql);

$totalUtilizedLimit = 0; // Default value if no cards found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalUtilizedLimit = $row['total_utilized_limit'];
}





// Fetch total credit card limit (sum of total limits)
$sql = "SELECT SUM(total_limit) AS total_credit_card_limit FROM credit_cards";
$result = $conn->query($sql);

$totalCreditCardLimit = 0; // Default value if no cards found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalCreditCardLimit = $row['total_credit_card_limit'];
}






// Fetch card owner and count of cards for each owner
$sql = "SELECT card_owner, COUNT(*) AS card_count FROM credit_cards GROUP BY card_owner";
$result = $conn->query($sql);

$cardOwners = array(); // Array to store card owner and count

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $cardOwners[$row['card_owner']] = $row['card_count'];
    }
}





// Loan databse start from here 



	

// Fetch total loan amount
$sql = "SELECT SUM(total_amount) AS total_loan_amount FROM loans";
$result = $conn->query($sql);

$totalLoanAmount = 0; // Default value if no loans found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalLoanAmount = $row['total_loan_amount'];
}

// Fetch total number of EMIs
$sql = "SELECT SUM(paid_emi) AS total_paid_emi, SUM(pending_emi) AS total_pending_emi FROM loans";
$result = $conn->query($sql);

$totalPaidEMI = 0; // Default value if no EMIs found
$totalPendingEMI = 0; // Default value if no EMIs found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalPaidEMI = $row['total_paid_emi'];
    $totalPendingEMI = $row['total_pending_emi'];
}

// Fetch total principle amount
$sql = "SELECT SUM(principle_amount) AS total_principle_amount FROM loans";
$result = $conn->query($sql);

$totalPrincipleAmount = 0; // Default value if no loans found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalPrincipleAmount = $row['total_principle_amount'];
}

// Fetch total interest
$sql = "SELECT SUM(interest) AS total_interest FROM loans";
$result = $conn->query($sql);

$totalInterest = 0; // Default value if no loans found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalInterest = $row['total_interest'];
}

// Fetch total paid amount
$sql = "SELECT SUM(paid_amount) AS total_paid_amount FROM loans";
$result = $conn->query($sql);

$totalPaidAmount = 0; // Default value if no loans found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalPaidAmount = $row['total_paid_amount'];
}

// Fetch total pending amount
$sql = "SELECT SUM(pending_amount) AS total_pending_amount FROM loans";
$result = $conn->query($sql);

$totalPendingAmount = 0; // Default value if no loans found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalPendingAmount = $row['total_pending_amount'];
}

// Fetch total number of owners
$sql = "SELECT COUNT(DISTINCT loan_owner) AS total_owners FROM loans";
$result = $conn->query($sql);

$totalOwners = 0; // Default value if no loans found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalOwners = $row['total_owners'];
}








// Fetch loan owner, count of loans, and total EMI amounts for each owner
$sql = "SELECT loan_owner, COUNT(*) AS loan_count, SUM(emi_amount) AS total_emi_amount FROM loans GROUP BY loan_owner";
$result = $conn->query($sql);

$loanOwners = array(); // Array to store loan owner, count, and total EMI amount

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $loanOwners[$row['loan_owner']] = array(
            'loan_count' => $row['loan_count'],
            'total_emi_amount' => $row['total_emi_amount']
        );
    }
}




// Fetch total monthly EMI amount (sum of all EMI amounts)
$sql = "SELECT SUM(emi_amount) AS total_monthly_emi FROM loans";
$result = $conn->query($sql);

$totalMonthlyEmi = 0; // Default value if no loans found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalMonthlyEmi = $row['total_monthly_emi'];
}



	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
// loan ends from here 





// debts start from here 

// Fetch total number of debts
$sql = "SELECT COUNT(*) AS total_debts FROM debt_details";
$result = $conn->query($sql);

$totalDebts = 0; // Default value if no debts found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalDebts = $row['total_debts'];
}

// Fetch total debt amount
$sql = "SELECT SUM(creditor_amount) AS total_debt_amount FROM debt_details";
$result = $conn->query($sql);

$totalDebtAmount = 0; // Default value if no debts found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalDebtAmount = $row['total_debt_amount'];
}

// Fetch total amount paid
$sql = "SELECT SUM(paid_amount) AS total_amount_paid FROM debt_details";
$result = $conn->query($sql);

$totalAmountPaid = 0; // Default value if no debts found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalAmountPaid = $row['total_amount_paid'];
}

// pending amount

// SQL query to fetch the sum of all pending amounts
// SQL query to fetch the sum of all pending amounts
$sql = "SELECT SUM(pending_amount) AS total_pending_amount FROM debt_details";

// Debugging: Output the SQL query


// Execute the query
$result = $conn->query($sql);

// Check if the query was successful
if ($result) {
    // Fetch the result
    $row = $result->fetch_assoc();

    // Debugging: Output the fetched row
 

    // Check if there are any pending amounts
    if ($row['total_pending_amount'] !== null) {
        $totalPendingAmount = $row['total_pending_amount'];
    } else {
        // If there are no pending amounts, set the total to 0
        $totalPendingAmount = 0;
    }

   
} else {
    // If there was an error in the query, output the error message
    echo "Error: " . $conn->error;
}








// Fetch total available balance (sum of available balances)
$sql = "SELECT SUM(available_balance) AS total_available_balance FROM bank";
$result = $conn->query($sql);

$totalAvailableBalance = 0; // Default value if no banks found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalAvailableBalance = $row['total_available_balance'];
}


// Fetch total invested amount (sum of invested amounts)
$sql = "SELECT SUM(InvestedAmount) AS total_invested_amount FROM investments";
$result = $conn->query($sql);

$totalInvestedAmount = 0; // Default value if no investments found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalInvestedAmount = $row['total_invested_amount'];
}

// Fetch total profit/loss (sum of profit/loss amounts)
$sql = "SELECT SUM(ProfitLoss) AS total_profit_loss FROM investments";
$result = $conn->query($sql);

$totalProfitLoss = 0; // Default value if no investments found

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalProfitLoss = $row['total_profit_loss'];
}











// Query to count total credit amount
$sqlTotalCreditAmount = "SELECT SUM(Amount) AS totalCreditAmount FROM credit";
$resultTotalCreditAmount = $conn->query($sqlTotalCreditAmount);
$totalCreditAmount = 0;
if ($resultTotalCreditAmount->num_rows > 0) {
    $row = $resultTotalCreditAmount->fetch_assoc();
    $totalCreditAmount = $row["totalCreditAmount"];
}

// Query to count total number of creditors
$sqlTotalCreditors = "SELECT COUNT(*) AS totalCreditors FROM credit";
$resultTotalCreditors = $conn->query($sqlTotalCreditors);
$totalCreditors = 0;
if ($resultTotalCreditors->num_rows > 0) {
    $row = $resultTotalCreditors->fetch_assoc();
    $totalCreditors = $row["totalCreditors"];
}












// Query to count total number of assets
$sqlTotalAssets = "SELECT COUNT(*) AS totalAssets FROM asset";
$resultTotalAssets = $conn->query($sqlTotalAssets);
$totalAssets = 0;
if ($resultTotalAssets->num_rows > 0) {
    $row = $resultTotalAssets->fetch_assoc();
    $totalAssets = $row["totalAssets"];
}

// Query to calculate total value of assets
$sqlTotalAssetValue = "SELECT SUM(Asset_Current_Value) AS totalAssetValue FROM asset";
$resultTotalAssetValue = $conn->query($sqlTotalAssetValue);
$totalAssetValue = 0;
if ($resultTotalAssetValue->num_rows > 0) {
    $row = $resultTotalAssetValue->fetch_assoc();
    $totalAssetValue = $row["totalAssetValue"];
}











// Query to calculate total cash amount
$sqlTotalCashAmount = "SELECT SUM(Cash_Amount) AS totalCashAmount FROM cash";
$resultTotalCashAmount = $conn->query($sqlTotalCashAmount);
$totalCashAmount = 0;
if ($resultTotalCashAmount->num_rows > 0) {
    $row = $resultTotalCashAmount->fetch_assoc();
    $totalCashAmount = $row["totalCashAmount"];

}













	
// Close connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Financial Dashboard</title>
    <!-- Bootstrap CSS -->
   
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <!-- Custom CSS -->
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-color: #ecf0f1;
            --dark-color: #2c3e50;
            --success-color: #27ae60;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7fa;
        }
        
        .dashboard-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 20px 0;
            margin-bottom: 30px;
            border-radius: 0 0 10px 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        .panel-heading {
            transition: all 0.3s ease;
            border-radius: 5px 5px 0 0 !important;
            color: white !important;
        }
        
        .panel-heading:hover {
            background-color: var(--secondary-color) !important;
        }
        
        .panel-title a {
            display: block;
            text-decoration: none;
            font-weight: 600;
        }
        
        .panel-body {
            padding: 20px;
            background-color: white;
            border-radius: 0 0 5px 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .card {
            border: none;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.15);
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
            padding: 12px 15px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .value-display {
            font-size: 1.8rem;
            font-weight: 700;
            margin: 10px 0;
        }
        
        .positive-value {
            color: var(--success-color);
        }
        
        .negative-value {
            color: var(--accent-color);
        }
        
        .neutral-value {
            color: var(--secondary-color);
        }
        
        .summary-card {
            border-left: 4px solid var(--secondary-color);
        }
        
        .progress {
            height: 8px;
            border-radius: 4px;
            margin-top: 10px;
        }
        
        .progress-bar {
            background-color: var(--secondary-color);
        }
        
        .owner-card {
            border-left: 4px solid var(--success-color);
            margin-bottom: 15px;
        }
        
        .floating-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 1000;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background-color: var(--accent-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
        }
        
        .floating-btn:hover {
            transform: scale(1.1);
            background-color: #c0392b;
            color: white;
        }
        
        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
            color: var(--secondary-color);
        }
        
        @media (max-width: 768px) {
            .value-display {
                font-size: 1.4rem;
            }
            
            .stat-icon {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Dashboard Header -->
    <div class="dashboard-header text-center animate__animated animate__fadeInDown">
        <div class="container">
            <h1><i class="fas fa-chart-line"></i> Financial Dashboard</h1>
            <p class="lead">Comprehensive overview of your financial health</p>
        </div>
    </div>

    <div class="container">
        <!-- Accordion Panels -->
        <div class="panel-group" id="accordion">
            <!-- Credit Card Panel -->
            <div class="panel panel-default mb-4">
                <div class="panel-heading" style="background-color: var(--primary-color);">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
                            <i class="fas fa-credit-card mr-2"></i> Credit Card Summary
                        </a>
                    </h4>
                </div>
                <div id="collapse1" class="panel-collapse collapse show">
                    <div class="panel-body animate__animated animate__fadeIn">
                        <div class="row">
                            <!-- Total Cards -->
                            <div class="col-md-4">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-credit-card stat-icon"></i>
                                        <h5 class="card-title">Total Credit Cards</h5>
                                        <div class="value-display neutral-value"><?php echo $totalCards; ?></div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Total Limit -->
                            <div class="col-md-4">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-money-bill-wave stat-icon"></i>
                                        <h5 class="card-title">Total Credit Limit</h5>
                                        <div class="value-display">₹<?php echo number_format($totalCreditCardLimit, 2); ?></div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Utilization -->
                            <div class="col-md-4">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-percentage stat-icon"></i>
                                        <h5 class="card-title">Credit Utilization</h5>
                                        <?php 
                                            $utilizationPercent = ($totalCreditCardLimit > 0) ? 
                                                ($totalUtilizedLimit / $totalCreditCardLimit) * 100 : 0;
                                            $utilizationClass = ($utilizationPercent > 70) ? 'negative-value' : 'positive-value';
                                        ?>
                                        <div class="value-display <?php echo $utilizationClass; ?>">
                                            <?php echo number_format($utilizationPercent, 2); ?>%
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" 
                                                 style="width: <?php echo $utilizationPercent; ?>%" 
                                                 aria-valuenow="<?php echo $utilizationPercent; ?>" 
                                                 aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <small>₹<?php echo number_format($totalUtilizedLimit, 2); ?> of ₹<?php echo number_format($totalCreditCardLimit, 2); ?></small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Card Owners -->
                        <div class="mt-4">
                            <h5 class="text-center mb-3"><i class="fas fa-users"></i> Card Owners</h5>
                            <div class="row">
                                <?php foreach ($cardOwners as $owner => $count): ?>
                                <div class="col-md-4">
                                    <div class="card owner-card h-100">
                                        <div class="card-body text-center">
                                            <h5 class="card-title"><i class="fas fa-user-tie"></i> <?php echo $owner; ?></h5>
                                            <p class="card-text"><span class="badge badge-primary"><?php echo $count; ?> cards</span></p>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Loan Panel -->
            <div class="panel panel-default mb-4">
                <div class="panel-heading" style="background-color: var(--primary-color);">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
                            <i class="fas fa-hand-holding-usd mr-2"></i> Loan Summary
                        </a>
                    </h4>
                </div>
                <div id="collapse2" class="panel-collapse collapse">
                    <div class="panel-body animate__animated animate__fadeIn">
                        <div class="row">
                            <!-- Total Loan Amount -->
                            <div class="col-md-3">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-file-invoice-dollar stat-icon"></i>
                                        <h5 class="card-title">Total Loan Amount</h5>
                                        <div class="value-display">₹<?php echo number_format($totalLoanAmount, 2); ?></div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- EMI Summary -->
                            <div class="col-md-3">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-calendar-check stat-icon"></i>
                                        <h5 class="card-title">EMI Summary</h5>
                                        <div class="value-display neutral-value"><?php echo $totalPaidEMI + $totalPendingEMI; ?></div>
                                        <div class="progress mt-2">
                                            <div class="progress-bar" role="progressbar" 
                                                 style="width: <?php echo (($totalPaidEMI + $totalPendingEMI) > 0) ? ($totalPaidEMI / ($totalPaidEMI + $totalPendingEMI)) * 100 : 0; ?>%" 
                                                 aria-valuenow="<?php echo $totalPaidEMI; ?>" 
                                                 aria-valuemin="0" 
                                                 aria-valuemax="<?php echo $totalPaidEMI + $totalPendingEMI; ?>"></div>
                                        </div>
                                        <small><?php echo $totalPaidEMI; ?> paid / <?php echo $totalPendingEMI; ?> pending</small>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Amount Summary -->
                            <div class="col-md-3">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-money-bill-alt stat-icon"></i>
                                        <h5 class="card-title">Amount Summary</h5>
                                        <div class="value-display positive-value">₹<?php echo number_format($totalPaidAmount, 2); ?></div>
                                        <div class="value-display negative-value">₹<?php echo number_format($totalPendingAmount, 2); ?></div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Monthly EMI -->
                            <div class="col-md-3">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-calendar-alt stat-icon"></i>
                                        <h5 class="card-title">Monthly EMI</h5>
                                        <div class="value-display">₹<?php echo number_format($totalMonthlyEmi, 2); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Loan Owners -->
                        <div class="mt-4">
                            <h5 class="text-center mb-3"><i class="fas fa-user-friends"></i> Loan Owners</h5>
                            <div class="row">
                                <?php foreach ($loanOwners as $owner => $details): ?>
                                <div class="col-md-4">
                                    <div class="card owner-card h-100">
                                        <div class="card-body text-center">
                                            <h5 class="card-title"><i class="fas fa-user"></i> <?php echo $owner; ?></h5>
                                            <p class="card-text"><span class="badge badge-primary"><?php echo $details['loan_count']; ?> loans</span></p>
                                            <p class="card-text"><span class="badge badge-info">₹<?php echo number_format($details['total_emi_amount'], 2); ?> monthly EMI</span></p>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Other Panels (Debt, Bank, Investment, etc.) -->
            <!-- Similar structure as above panels -->
            <!-- Debt Panel -->
            <div class="panel panel-default mb-4">
                <div class="panel-heading" style="background-color: var(--primary-color);">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">
                            <i class="fas fa-file-invoice-dollar mr-2"></i> Debt Summary
                        </a>
                    </h4>
                </div>
                <div id="collapse3" class="panel-collapse collapse">
                    <div class="panel-body animate__animated animate__fadeIn">
                        <div class="row">
                            <!-- Total Debts -->
                            <div class="col-md-4">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-file-invoice stat-icon"></i>
                                        <h5 class="card-title">Total Debts</h5>
                                        <div class="value-display neutral-value"><?php echo $totalDebts; ?></div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Total Debt Amount -->
                            <div class="col-md-4">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-money-bill-wave stat-icon"></i>
                                        <h5 class="card-title">Total Debt Amount</h5>
                                        <div class="value-display negative-value">₹<?php echo number_format($totalDebtAmount, 2); ?></div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Paid vs Pending -->
                            <div class="col-md-4">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-balance-scale stat-icon"></i>
                                        <h5 class="card-title">Paid vs Pending</h5>
                                        <div class="value-display positive-value">₹<?php echo number_format($totalAmountPaid, 2); ?></div>
                                        <div class="value-display negative-value">₹<?php echo number_format($totalPendingAmount, 2); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Bank Panel -->
            <div class="panel panel-default mb-4">
                <div class="panel-heading" style="background-color: var(--primary-color);">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">
                            <i class="fas fa-university mr-2"></i> Bank Summary
                        </a>
                    </h4>
                </div>
                <div id="collapse4" class="panel-collapse collapse">
                    <div class="panel-body animate__animated animate__fadeIn">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card text-center">
                                    <div class="card-body">
                                        <i class="fas fa-piggy-bank stat-icon"></i>
                                        <h5 class="card-title">Total Available Balance</h5>
                                        <div class="value-display positive-value">₹<?php echo number_format($totalAvailableBalance, 2); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Investment Panel -->
            <div class="panel panel-default mb-4">
                <div class="panel-heading" style="background-color: var(--primary-color);">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse5">
                            <i class="fas fa-chart-pie mr-2"></i> Investment Summary
                        </a>
                    </h4>
                </div>
                <div id="collapse5" class="panel-collapse collapse">
                    <div class="panel-body animate__animated animate__fadeIn">
                        <div class="row">
                            <!-- Total Invested -->
                            <div class="col-md-6">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-coins stat-icon"></i>
                                        <h5 class="card-title">Total Invested</h5>
                                        <div class="value-display">₹<?php echo number_format($totalInvestedAmount, 2); ?></div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Profit/Loss -->
                            <div class="col-md-6">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-chart-line stat-icon"></i>
                                        <h5 class="card-title">Profit/Loss</h5>
                                        <div class="value-display <?php echo ($totalProfitLoss >= 0) ? 'positive-value' : 'negative-value'; ?>">
                                            ₹<?php echo number_format($totalProfitLoss, 2); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Credit Panel -->
            <div class="panel panel-default mb-4">
                <div class="panel-heading" style="background-color: var(--primary-color);">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse6">
                            <i class="fas fa-hand-holding-usd mr-2"></i> Credit Summary
                        </a>
                    </h4>
                </div>
                <div id="collapse6" class="panel-collapse collapse">
                    <div class="panel-body animate__animated animate__fadeIn">
                        <div class="row">
                            <!-- Total Credit Amount -->
                            <div class="col-md-6">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-money-bill-alt stat-icon"></i>
                                        <h5 class="card-title">Total Credit Amount</h5>
                                        <div class="value-display positive-value">₹<?php echo number_format($totalCreditAmount, 2); ?></div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Total Creditors -->
                            <div class="col-md-6">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-users stat-icon"></i>
                                        <h5 class="card-title">Total Creditors</h5>
                                        <div class="value-display neutral-value"><?php echo $totalCreditors; ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Asset Panel -->
            <div class="panel panel-default mb-4">
                <div class="panel-heading" style="background-color: var(--primary-color);">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse7">
                            <i class="fas fa-home mr-2"></i> Asset Summary
                        </a>
                    </h4>
                </div>
                <div id="collapse7" class="panel-collapse collapse">
                    <div class="panel-body animate__animated animate__fadeIn">
                        <div class="row">
                            <!-- Total Assets -->
                            <div class="col-md-6">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-boxes stat-icon"></i>
                                        <h5 class="card-title">Total Assets</h5>
                                        <div class="value-display neutral-value"><?php echo $totalAssets; ?></div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Total Asset Value -->
                            <div class="col-md-6">
                                <div class="card text-center h-100">
                                    <div class="card-body">
                                        <i class="fas fa-dollar-sign stat-icon"></i>
                                        <h5 class="card-title">Total Asset Value</h5>
                                        <div class="value-display positive-value">₹<?php echo number_format($totalAssetValue, 2); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Cash Panel -->
            <div class="panel panel-default mb-4">
                <div class="panel-heading" style="background-color: var(--primary-color);">
                    <h4 class="panel-title">
                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse8">
                            <i class="fas fa-money-bill-wave mr-2"></i> Cash Summary
                        </a>
                    </h4>
                </div>
                <div id="collapse8" class="panel-collapse collapse">
                    <div class="panel-body animate__animated animate__fadeIn">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card text-center">
                                    <div class="card-body">
                                        <i class="fas fa-wallet stat-icon"></i>
                                        <h5 class="card-title">Total Cash Amount</h5>
                                        <div class="value-display positive-value">₹<?php echo number_format($totalCashAmount, 2); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Financial Health Summary -->
        <div class="card summary-card mt-4 mb-5 animate__animated animate__fadeInUp">
            <div class="card-header">
                <h4><i class="fas fa-heartbeat mr-2"></i> Financial Health Summary</h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <div class="text-center">
                            <i class="fas fa-arrow-circle-up fa-3x text-success mb-2"></i>
                            <h5>Total Assets</h5>
                            <h3 class="positive-value">₹<?php echo number_format($totalAssetValue + $totalAvailableBalance + $totalInvestedAmount + $totalCashAmount, 2); ?></h3>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center">
                            <i class="fas fa-arrow-circle-down fa-3x text-danger mb-2"></i>
                            <h5>Total Liabilities</h5>
                            <h3 class="negative-value">₹<?php echo number_format($totalLoanAmount + $totalDebtAmount + $totalCreditCardLimit, 2); ?></h3>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center">
                            <i class="fas fa-balance-scale fa-3x text-primary mb-2"></i>
                            <h5>Net Worth</h5>
                            <?php 
                                $netWorth = ($totalAssetValue + $totalAvailableBalance + $totalInvestedAmount + $totalCashAmount) - 
                                            ($totalLoanAmount + $totalDebtAmount + $totalCreditCardLimit);
                                $netWorthClass = ($netWorth >= 0) ? 'positive-value' : 'negative-value';
                            ?>
                            <h3 class="<?php echo $netWorthClass; ?>">₹<?php echo number_format($netWorth, 2); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Floating Action Button -->
    <a href="dashboard.php" class="floating-btn animate__animated animate__bounceInUp">
        <i class="fas fa-home"></i>
    </a>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <!-- Custom JS for animations -->
    <script>
        $(document).ready(function() {
            // Add animation when panels are shown
            $('.panel-collapse').on('show.bs.collapse', function () {
                $(this).addClass('animate__animated animate__fadeIn');
            });
            
            // Smooth scroll for anchor links
            $('a[href^="#"]').on('click', function(event) {
                var target = $(this.getAttribute('href'));
                if( target.length ) {
                    event.preventDefault();
                    $('html, body').stop().animate({
                        scrollTop: target.offset().top - 20
                    }, 1000);
                }
            });
        });
    </script>
</body>
</html>