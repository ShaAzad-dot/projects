<?php
// Database connection parameters
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch available balance for the selected bank
$selectedBank = $_GET['bank'];
$sql = "SELECT available_balance FROM bank WHERE bank_name = '$selectedBank'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $availableBalance = $row['available_balance'];
    echo $availableBalance;
} else {
    // If no data is found, return a default value
    echo "0";
}

// Close connection
$conn->close();
?>
