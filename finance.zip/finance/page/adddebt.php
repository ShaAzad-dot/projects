<?php include 'includes/header.php'?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Debt Details</title>
    
</head>
<body>
    <div class="container mt-5">
        <div class="card shadow p-4">
            <h2 class="text-center mb-4">Add Debt Details</h2>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="needs-validation" novalidate>
                <div class="mb-3">
                    <label for="creditor_name" class="form-label">Creditor Name:</label>
                    <input type="text" class="form-control" id="creditor_name" name="creditor_name" required>
                </div>
                <div class="mb-3">
                    <label for="creditor_amount" class="form-label">Creditor Amount:</label>
                    <input type="number" step="0.01" class="form-control" id="creditor_amount" name="creditor_amount" required>
                </div>
                <div class="mb-3">
                    <label for="tenure" class="form-label">Tenure (months):</label>
                    <input type="number" class="form-control" id="tenure" name="tenure" required>
                </div>
                <div class="mb-3">
                    <label for="paid_amount" class="form-label">Paid Amount:</label>
                    <input type="number" step="0.01" class="form-control" id="paid_amount" name="paid_amount" required>
                </div>
                <div class="mb-3">
                    <label for="pending_amount" class="form-label">Pending Amount:</label>
                    <input type="text" class="form-control" id="pending_amount" name="pending_amount" readonly>
                </div>
                <div class="mb-3">
                    <label for="payoff_date" class="form-label">Payoff Date:</label>
                    <input type="date" class="form-control" id="payoff_date" name="payoff_date" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Submit</button>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('paid_amount').addEventListener('input', function() {
            let creditorAmount = parseFloat(document.getElementById('creditor_amount').value) || 0;
            let paidAmount = parseFloat(this.value) || 0;
            document.getElementById('pending_amount').value = (creditorAmount - paidAmount).toFixed(2);
        });
    </script>
</body>
</html>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "finance";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $creditorName = $_POST["creditor_name"];
    $creditorAmount = $_POST["creditor_amount"];
    $tenure = $_POST["tenure"];
    $paidAmount = $_POST["paid_amount"];
    $pendingAmount = $creditorAmount - $paidAmount;
    $payoffDate = $_POST["payoff_date"];

    $sql = "INSERT INTO debt_details (creditor_name, creditor_amount, tenure, pending_amount, paid_amount, payoff_date)
            VALUES ('$creditorName', '$creditorAmount', '$tenure', '$pendingAmount', '$paidAmount', '$payoffDate')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>Record added successfully!</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error: " . $conn->error . "</div></div>";
    }
}

$conn->close();
?>
