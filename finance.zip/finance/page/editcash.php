
php
Copy code
<?php
require_once 'includes/header.php'; 

// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    echo "Error: No cash ID provided.";
    exit();
}

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch cash details based on ID
$id = $_GET['id'];
$sql = "SELECT * FROM cash WHERE id = $id"; // Updated to use the correct column name
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Error: Cash details not found.";
    exit();
}

// Initialize variables with current data
$cashFrom = $row['Cash_From'];
$cashAmount = $row['Cash_Amount'];
$date = $row['Date'];

// Update cash details if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $cashFrom = $_POST["cash_from"];
    $cashAmount = $_POST["cash_amount"];
    $date = $_POST["date"];

    // Update SQL query
    $updateSql = "UPDATE cash SET Cash_From='$cashFrom', Cash_Amount='$cashAmount', Date='$date' WHERE id=$id"; // Updated to use the correct column name

    if ($conn->query($updateSql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>Record updated successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error updating record: " . $conn->error . "</div></div>";
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Cash Details</title>
    <!-- Bootstrap CSS -->
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Cash Details</h2>
        <form id="cashForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $id; ?>" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="cash_from">Cash From:</label>
                <input type="text" class="form-control" id="cash_from" name="cash_from" value="<?php echo $cashFrom; ?>" required>
                <div class="invalid-feedback">Please enter the source of cash.</div>
            </div>
            <div class="form-group">
                <label for="cash_amount">Cash Amount:</label>
                <input type="text" class="form-control" id="cash_amount" name="cash_amount" value="<?php echo $cashAmount; ?>" required>
                <div class="invalid-feedback">Please enter the cash amount.</div>
            </div>
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" class="form-control" id="date" name="date" value="<?php echo $date; ?>" required>
                <div class="invalid-feedback">Please enter the date.</div>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="cash_details.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Form validation script -->
    <script>
        // JavaScript for form validation
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
    </script>
</body>
</html>
