
<?php require_once 'includes/header.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Income Details</title>
    <!-- Bootstrap CSS -->
  
</head>
<body>
    <div class="container mt-5">
        <ol class="breadcrumb">
            <li><a href="dashboard.php">Home</a></li>          
            <li class="active"> Add Income Details</li>
        </ol>
        <h2>Add Income Details</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control" id="name" name="name" required>
                <div class="invalid-feedback">Please enter the name.</div>
            </div>
            <div class="form-group">
                <label for="income_type">Income Type:</label>
                <input type="text" class="form-control" id="income_type" name="income_type" required>
                <div class="invalid-feedback">Please enter the income type.</div>
            </div>
            <div class="form-group">
                <label for="amount">Amount:</label>
                <input type="text" class="form-control" id="amount" name="amount" required>
                <div class="invalid-feedback">Please enter the amount.</div>
            </div>
            <div class="form-group">
                <label for="income_date">Income Date:</label>
                <input type="date" class="form-control" id="income_date" name="income_date" required>
                <div class="invalid-feedback">Please enter the income date.</div>
            </div>
            <div class="form-group">
                <label for="received_in_account">Select Bank:</label>
                <select class="form-control" id="received_in_account" name="received_in_account" required>
                    <option value="" selected disabled>Select a Bank</option>
                    <?php
                    // Fetching bank data from the database
                    $servername = "localhost"; // Change this if your database is hosted elsewhere
                    $username = "root";
                    $password = "";
                    $database = "finance";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $database);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Query to fetch bank names and available balances
                    $sql = "SELECT bank_name, available_balance FROM bank";

                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Output data of each row
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row['bank_name'] . "' data-balance='" . $row['available_balance'] . "'>" . $row['bank_name'] . " - Available Balance: INR " . $row['available_balance'] . "</option>";
                        }
                    } else {
                        echo "<option value='' disabled>No banks found</option>";
                    }

                    // Close connection
                    $conn->close();
                    ?>
                </select>
                <div class="invalid-feedback">Please select a bank.</div>
            </div>
            <div class="form-group">
                <label for="description">Description:</label>
                <input type="text" class="form-control" id="description" name="description">
            </div>
            <button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-plus-sign"></i>   Submit</button>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Form validation script -->
    <script>
        // JavaScript for form validation
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();

        // JavaScript for updating available balance dynamically
        $(document).ready(function() {
            $('#received_in_account').change(function() {
                var selectedOption = $(this).find(':selected');
                var balance = selectedOption.data('balance');
                $('#available_balance').val(balance);
            });
        });
    </script>
</body>
</html>

<?php
// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables to store form data
$name = $incomeType = $amount = $incomeDate = $receivedInAccount = $description = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $incomeType = $_POST["income_type"];
    $amount = $_POST["amount"];
    $incomeDate = $_POST["income_date"];
    $receivedInAccount = $_POST["received_in_account"];
    $description = $_POST["description"];

    // Update bank's available balance
    $sqlUpdateBalance = "UPDATE bank SET available_balance = available_balance + $amount WHERE bank_name = '$receivedInAccount'";
    if ($conn->query($sqlUpdateBalance) === FALSE) {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error updating available balance: " . $conn->error . "</div></div>";
    }

    // SQL to insert data into table
    $sql = "INSERT INTO income (name, income_type, amount, income_date, received_in_account, description)
            VALUES ('$name', '$incomeType', '$amount', '$incomeDate', '$receivedInAccount', '$description')";

    if ($conn->query($sql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>New record created successfully</div></div>";
    } else {
                "<div class='container mt-3'><div class='alert alert-danger'>Error: " . $sql . "<br>" . $conn->error . "</div></div>";
    }
}

// Close connection
$conn->close();
?>