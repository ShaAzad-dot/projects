<?php
require_once 'includes/header.php';

// Check if ID parameter exists
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: manageincome.php");
    exit;
}

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch income data based on ID
$id = $_GET['id'];
$sqlIncome = "SELECT * FROM income WHERE id = $id";
$resultIncome = $conn->query($sqlIncome);

if ($resultIncome->num_rows == 1) {
    $rowIncome = $resultIncome->fetch_assoc();
} else {
    echo "Income record not found";
    exit;
}

// Fetch bank data for dropdown
$sqlBank = "SELECT * FROM bank";
$resultBank = $conn->query($sqlBank);

if ($resultBank->num_rows > 0) {
    $bankOptions = "";
    while ($rowBank = $resultBank->fetch_assoc()) {
        $bankOptions .= "<option value='" . $rowBank['bank_name'] . "'";
        if ($rowIncome['received_in_account'] == $rowBank['bank_name']) {
            $bankOptions .= " selected";
        }
        $bankOptions .= ">" . $rowBank['bank_name'] . " (Available Balance: INR " . $rowBank['available_balance'] . ")</option>";
    }
} else {
    $bankOptions = "<option value='' disabled>No banks found</option>";
}

// Handle form submission for updating income data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $incomeType = $_POST["income_type"];
    $amount = $_POST["amount"];
    $incomeDate = $_POST["income_date"];
    $receivedInAccount = $_POST["received_in_account"];
    $description = $_POST["description"];

    // Calculate the difference in income amount
    $oldAmount = $rowIncome['amount'];
    $amountDifference = $amount - $oldAmount;

    // Update the income record
    $sqlUpdate = "UPDATE income SET name = '$name', income_type = '$incomeType', amount = '$amount', income_date = '$incomeDate', received_in_account = '$receivedInAccount', description = '$description' WHERE id = $id";

    if ($conn->query($sqlUpdate) === TRUE) {
        // Update the bank's available balance
        $sqlUpdateBank = "UPDATE bank SET available_balance = available_balance + $amountDifference WHERE bank_name = '$receivedInAccount'";
        if ($conn->query($sqlUpdateBank) !== TRUE) {
            echo "Error updating bank balance: " . $conn->error;
            exit;
        }

        header("Location: manageincome.php");
        exit;
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Income</title>
    <!-- Bootstrap CSS -->
</head>
<body>
<div class="container mt-5">
    <h2>Edit Income</h2>
    <form method="post">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo $rowIncome['name']; ?>" required>
        </div>
        <div class="form-group">
            <label for="income_type">Income Type:</label>
            <input type="text" class="form-control" id="income_type" name="income_type" value="<?php echo $rowIncome['income_type']; ?>" required>
        </div>
        <div class="form-group">
            <label for="amount">Amount:</label>
            <input type="text" class="form-control" id="amount" name="amount" value="<?php echo $rowIncome['amount']; ?>" required>
        </div>
        <div class="form-group">
            <label for="income_date">Income Date:</label>
            <input type="date" class="form-control" id="income_date" name="income_date" value="<?php echo $rowIncome['income_date']; ?>" required>
        </div>
        <div class="form-group">
            <label for="received_in_account">Received In Account:</label>
            <select class="form-control" id="received_in_account" name="received_in_account" required>
                <?php echo $bankOptions; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea class="form-control" id="description" name="description" rows="3"><?php echo $rowIncome['description']; ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
