<?php 
require_once 'includes/header.php';

// Database connection
$conn = new mysqli("localhost", "root", "", "finance");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Get current month-year
$currentMonth = date('Y-m');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Loan EMI Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .paid-badge { background-color: #28a745; }
        .unpaid-badge { background-color: #dc3545; }
        .due-soon { background-color: #fff3cd; }
        .overdue { background-color: #f8d7da; }
    </style>
</head>
<body>
<div class="container mt-4">
    <h2 class="text-center mb-4">Loan EMI Management - <?= date('F Y') ?></h2>
    
    <div class="card shadow">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h4 class="mb-0">Current Month EMI Status</h4>
                <a href="view_payments.php" class="btn btn-light">View All Payments</a>
            </div>
        </div>
        
        <div class="card-body">
            <table class="table table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Loan Name</th>
                        <th>EMI Amount</th>
                        <th>Due Date</th>
                        <th>Pending EMIs</th>
                        <th>Current Month Status</th>
                        <th>Payment Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Get loans with current month payment status
                    $sql = "SELECT l.*, p.status, p.payment_date 
                            FROM loans l
                            LEFT JOIN loan_payments p ON l.id = p.loan_id 
                            AND p.month_year = '$currentMonth'
                            ORDER BY l.emi_date ASC";
                    
                    $result = $conn->query($sql);
                    
                    while($row = $result->fetch_assoc()) {
                        $dueDate = date('Y-m') . '-' . date('d', strtotime($row['emi_date']));
                        $isPaid = $row['status'] == 'paid';
                        $isOverdue = !$isPaid && $dueDate < date('Y-m-d');
                        $isDueSoon = !$isPaid && $dueDate <= date('Y-m-d', strtotime('+7 days'));
                        
                        echo "<tr class='".($isOverdue ? 'overdue' : ($isDueSoon ? 'due-soon' : ''))."'>";
                        echo "<td>{$row['loan_name']}</td>";
                        echo "<td>₹".number_format($row['emi_amount'], 2)."</td>";
                        echo "<td>".date('d M', strtotime($dueDate))."</td>";
                        echo "<td>{$row['pending_emi']}</td>";
                        echo "<td><span class='badge ".($isPaid ? 'paid-badge' : 'unpaid-badge')."'>".ucfirst($row['status'] ?? 'unpaid')."</span></td>";
                        echo "<td>".($isPaid ? date('d M Y', strtotime($row['payment_date'])) : '-')."</td>";
                        echo "<td>";
                        if(!$isPaid) {
                            echo "<button class='btn btn-sm btn-success mark-paid' data-loan-id='{$row['loan_id']}'>Mark Paid</button>";
                        }
                        echo " <a href='view_payment.php?loan_id={$row['id']}' class='btn btn-sm btn-info'>View History</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('.mark-paid').click(function() {
        const loanId = $(this).data('loan-id');
        const paymentDate = prompt("Enter payment date (YYYY-MM-DD):", "<?= date('Y-m-d') ?>");
        
        if(paymentDate) {
            $.post('update_payment.php', {
                loan_id: loanId,
                payment_date: paymentDate,
                month_year: "<?= $currentMonth ?>",
                amount: $(this).closest('tr').find('td:nth-child(2)').text().replace('₹','')
            }, function(response) {
                if(response.success) {
                    location.reload();
                } else {
                    alert('Error: ' + response.message);
                }
            }, 'json');
        }
    });
});
</script>
</body>
</html>
<?php $conn->close(); ?>