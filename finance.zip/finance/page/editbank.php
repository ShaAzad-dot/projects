
<?php
require_once 'includes/header.php'; 

// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    echo "Error: No bank ID provided.";
    exit();
}

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch bank details based on ID
$id = $_GET['id'];
$sql = "SELECT * FROM bank WHERE id = $id"; // Changed 'bank_id' to 'id'
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    echo "Error: Bank not found.";
    exit();
}

// Initialize variables with current data
$bankName = $row['bank_name'];
$accountNumber = $row['account_number'];
$accountHolder = $row['account_holder'];
$minimumBalance = $row['minimum_balance'];
$availableBalance = $row['available_balance'];
$lastUpdateDate = $row['last_update_date'];

// Update bank details
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $bankName = $_POST["bank_name"];
    $accountNumber = $_POST["account_number"];
    $accountHolder = $_POST["account_holder"];
    $minimumBalance = $_POST["minimum_balance"];
    $availableBalance = $_POST["available_balance"];
    $lastUpdateDate = $_POST["last_update_date"];

    $updateSql = "UPDATE bank SET bank_name='$bankName', account_number='$accountNumber', account_holder='$accountHolder', minimum_balance='$minimumBalance', available_balance='$availableBalance', last_update_date='$lastUpdateDate' WHERE id=$id";

    if ($conn->query($updateSql) === TRUE) {
        echo "<div class='container mt-3'><div class='alert alert-success'>Record updated successfully</div></div>";
    } else {
        echo "<div class='container mt-3'><div class='alert alert-danger'>Error updating record: " . $conn->error . "</div></div>";
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Bank Details</title>
    <!-- Bootstrap CSS -->
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Bank Details</h2>
        <form id="bankForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $id; ?>" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="bank_name">Bank Name:</label>
                <input type="text" class="form-control" id="bank_name" name="bank_name" value="<?php echo $bankName; ?>" required>
                <div class="invalid-feedback">Please enter the bank name.</div>
            </div>
            <div class="form-group">
                <label for="account_number">Account Number:</label>
                <input type="text" class="form-control" id="account_number" name="account_number" value="<?php echo $accountNumber; ?>" required>
                <div class="invalid-feedback">Please enter the account number.</div>
            </div>
            <div class="form-group">
                <label for="account_holder">Account Holder:</label>
                <input type="text" class="form-control" id="account_holder" name="account_holder" value="<?php echo $accountHolder; ?>" required>
                <div class="invalid-feedback">Please enter the account holder's name.</div>
            </div>
            <div class="form-group">
                <label for="minimum_balance">Minimum Balance:</label>
                <input type="number" class="form-control" id="minimum_balance" name="minimum_balance" value="<?php echo $minimumBalance; ?>" required>
                <div class="invalid-feedback">Please enter the minimum balance.</div>
            </div>
            <div class="form-group">
                <label for="available_balance">Available Balance:</label>
                <input type="number" class="form-control" id="available_balance" name="available_balance" value="<?php echo $availableBalance; ?>" required>
                <div class="invalid-feedback">Please enter the available balance.</div>
            </div>
            <div class="form-group">
                <label for="last_update_date">Last Update Date:</label>
                <input type="date" class="form-control" id="last_update_date" name="last_update_date" value="<?php echo $lastUpdateDate; ?>" required>
                <div class="invalid-feedback">Please enter the last update date.</div>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="bank_list.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Form validation script -->
    <script>
        // JavaScript for form validation
        (function() {
            'use strict';
            window.addEventListener('load', function() {
                // Fetch all the forms we want to apply custom Bootstrap validation styles to
                var forms = document.getElementsByClassName('needs-validation');
                // Loop over them and prevent submission
                var validation = Array.prototype.filter.call(forms, function(form) {
                    form.addEventListener('submit', function(event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add('was-validated');
                    }, false);
                });
            }, false);
        })();
    </script>
</body>
</html>
