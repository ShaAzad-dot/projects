
<?php
require_once 'includes/header.php';

// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    echo "Error: No bank ID provided.";
    exit();
}

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete bank details
$id = $_GET['id'];
$sql = "DELETE FROM bank WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    echo "<div class='container mt-3'><div class='alert alert-success'>Record deleted successfully  <a href='managebank.php'><button class='btn btn-primary'>Bank List
						</button></a></div>
	</div>";
} else {
    echo "<div class='container mt-3'><div class='alert alert-danger'>Error deleting record: " . $conn->error . "</div></div>";
}

// Close connection
$conn->close();
?>
