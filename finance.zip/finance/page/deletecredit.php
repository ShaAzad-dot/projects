
<?php
require_once 'includes/header.php';

// Check if ID parameter is provided
if (!isset($_GET['id'])) {
    echo "Error: No credit ID provided.";
    exit();
}

// Database connection
$servername = "localhost"; // Change this if your database is hosted elsewhere
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get ID parameter
$id = $_GET['id'];

// Delete credit entry from the database
$sql = "DELETE FROM Credit WHERE ID = $id";

if ($conn->query($sql) === TRUE) {
    echo "<div class='container mt-3'><div class='alert alert-success'>Credit entry deleted successfully</div></div>";
} else {
    echo "<div class='container mt-3'><div class='alert alert-danger'>Error deleting credit entry: " . $conn->error . "</div></div>";
}

// Close connection
$conn->close();
?>
