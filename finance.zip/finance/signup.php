<?php
require 'page/includes/dbconnection.php'; // Ensure this file contains the database connection

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $mobile = trim($_POST['mobile']);
    $password = trim($_POST['password']);

    // Validate inputs
    if (empty($username) || empty($email) || empty($password)) {
        echo "All fields are required.";
    } else {
        // Check if email already exists
        $check_email_query = "SELECT * FROM users WHERE email = ?";
        $stmt = mysqli_prepare($connection, $check_email_query);
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            echo "Email already registered. Try logging in.";
        } else {
            // Hash password for security
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert into database
            $query = "INSERT INTO users (username, email, mobile, password_hash) VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($connection, $query);
            mysqli_stmt_bind_param($stmt, "ssss", $username, $email, $mobile, $hashed_password);

            if (mysqli_stmt_execute($stmt)) {
                echo "Account created successfully. <a href='login.php'>Login here</a>";
            } else {
                echo "Error: " . mysqli_error($connection);
            }
        }
    }
}
?>
